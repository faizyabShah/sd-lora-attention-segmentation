# Locked sg15 results

VOC only selects. SG15 source thresholds selected on four training folds; refined outputs inherit them. Full-VOC choices frozen before COCO metrics are interpreted. Diagnostic variants never promoted on COCO.

Same-generation audited controls; historical cross-hardware discrepancies are diagnostic only. Does not certify historical bit-identical reproduction.

| Cell | VOC OOF mIoU | Full VOC threshold | Full VOC mIoU | COCO mIoU |
|---|---:|---:|---:|---:|
| W/REF | 0.787280 | 0.425 | 0.788610 | 0.617163 |
| W/P1 | 0.799652 | 0.450 | 0.800585 | 0.624471 |
| W/SG11/trim20/rho0p80 | 0.798400 | 0.425 | 0.798400 | 0.621916 |
| W/SG12/top50 | 0.796658 | 0.450 | 0.798558 | 0.627174 |
| W/P1/SG15-A025 | 0.771825 | 0.450 | 0.772341 | 0.590097 |
| W/P1/SG15-A050 | 0.785750 | 0.450 | 0.786946 | 0.610955 |
| W/P1/SG15-A075 | 0.781210 | 0.450 | 0.783029 | 0.617070 |
| W/P1/SG15-B | 0.796477 | 0.450 | 0.797453 | 0.622908 |
| W/SG11/trim20/rho0p80/SG15-A025 | 0.774839 | 0.425 | 0.774839 | 0.591763 |
| W/SG11/trim20/rho0p80/SG15-A050 | 0.788200 | 0.425 | 0.788200 | 0.610175 |
| W/SG11/trim20/rho0p80/SG15-A075 | 0.786171 | 0.425 | 0.786171 | 0.613398 |
| W/SG11/trim20/rho0p80/SG15-B | 0.798934 | 0.425 | 0.798934 | 0.622023 |
| W/SG12/top50/SG15-A025 | 0.772646 | 0.450 | 0.774348 | 0.592589 |
| W/SG12/top50/SG15-A050 | 0.783663 | 0.450 | 0.786272 | 0.615600 |
| W/SG12/top50/SG15-A075 | 0.780167 | 0.450 | 0.782186 | 0.618773 |
| W/SG12/top50/SG15-B | 0.794904 | 0.450 | 0.797112 | 0.625986 |

## Protocol selection

| Screen | Winner | Votes | Selected OOF / REF | Gain | Frozen |
|---|---|---:|---:|---:|---|
| W/P1_SG15-A | W/P1 | 5/5 | 0.799652 / 0.799652 | +0.000000 | W/P1 |
| W/P1_SG15-B | W/P1 | 5/5 | 0.799652 / 0.799652 | +0.000000 | W/P1 |
| W/SG11/trim20/rho0p80_SG15-A | W/SG11/trim20/rho0p80 | 5/5 | 0.798400 / 0.798400 | +0.000000 | W/SG11/trim20/rho0p80 |
| W/SG11/trim20/rho0p80_SG15-B | W/SG11/trim20/rho0p80 | 5/5 | 0.798400 / 0.798400 | +0.000000 | W/SG11/trim20/rho0p80 |
| W/SG12/top50_SG15-A | W/SG12/top50 | 5/5 | 0.796658 / 0.796658 | +0.000000 | W/SG12/top50 |
| W/SG12/top50_SG15-B | W/SG12/top50 | 5/5 | 0.796658 / 0.796658 | +0.000000 | W/SG12/top50 |

Forced candidate OOF and protocol-selected OOF are distinct. All five fold winners, thresholds, class IoUs, deltas, paired 20k-bootstrap intervals and improved/worsened/tied counts are in summary.json and fold_results.json.

## Mechanism diagnostics

```json
{
  "voc": {
    "oracle_mean_image_iou": 0.8858825673928974,
    "legacy_SG13_nearest64_GT_oracle_mean_image_iou": 0.8751898845476893,
    "oracle_note": "Main diagnostic GT fractions are evaluated over annotation-resolution regions, as are prior occupancies. Legacy nearest64-GT SG13 oracle is also retained, never used by prediction.",
    "region_selected_definition": "at least 50% output occupancy in nonempty region; for majority projection equals its chosen label, for B a diagnostic summary of mixed regions",
    "cells": {
      "W/P1/SG15-A025": {
        "region_quality": {
          "foreground_regions_per_image": 18.979591836734695,
          "region_precision": 0.8311827956989247,
          "region_recall": 0.9549104385423101,
          "region_f1": 0.8887611382581201,
          "oracle_positive_regions_missed": 365,
          "oracle_negative_regions_selected": 1570,
          "oracle_positive_regions": 8095
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 17.751020408163264,
          "region_precision": 0.8721545182800644,
          "region_recall": 0.9371216800494132,
          "region_f1": 0.9034716846305008,
          "oracle_positive_regions_missed": 509,
          "oracle_negative_regions_selected": 1112,
          "oracle_positive_regions": 8095
        },
        "unrefined_mean_image_iou": 0.8032513708155546,
        "refined_mean_image_iou": 0.7704781839905209,
        "oracle_gap_before": 0.08263119657734275,
        "oracle_gap_after": 0.11540438340237646,
        "fraction_oracle_gap_closed": -0.396620019829412,
        "changes": {
          "all": {
            "FN_to_TP": 1144369,
            "FP_to_TN": 461666,
            "TP_to_FN": 314484,
            "TN_to_FP": 3206163,
            "useful": 1606035,
            "harmful": 3520647
          },
          "high_FG": {
            "FN_to_TP": 251913,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 593863,
            "useful": 251913,
            "harmful": 593863
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 461666,
            "TP_to_FN": 314484,
            "TN_to_FP": 0,
            "useful": 461666,
            "harmful": 314484
          },
          "mixed": {
            "FN_to_TP": 892456,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 2612300,
            "useful": 892456,
            "harmful": 2612300
          }
        }
      },
      "W/P1/SG15-A050": {
        "region_quality": {
          "foreground_regions_per_image": 17.751020408163264,
          "region_precision": 0.8721545182800644,
          "region_recall": 0.9371216800494132,
          "region_f1": 0.9034716846305008,
          "oracle_positive_regions_missed": 509,
          "oracle_negative_regions_selected": 1112,
          "oracle_positive_regions": 8095
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 17.751020408163264,
          "region_precision": 0.8721545182800644,
          "region_recall": 0.9371216800494132,
          "region_f1": 0.9034716846305008,
          "oracle_positive_regions_missed": 509,
          "oracle_negative_regions_selected": 1112,
          "oracle_positive_regions": 8095
        },
        "unrefined_mean_image_iou": 0.8032513708155546,
        "refined_mean_image_iou": 0.7880960906255791,
        "oracle_gap_before": 0.08263119657734275,
        "oracle_gap_after": 0.09778647676731833,
        "fraction_oracle_gap_closed": -0.18340869813969415,
        "changes": {
          "all": {
            "FN_to_TP": 647267,
            "FP_to_TN": 1070588,
            "TP_to_FN": 945646,
            "TN_to_FP": 1597941,
            "useful": 1717855,
            "harmful": 2543587
          },
          "high_FG": {
            "FN_to_TP": 251913,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 593863,
            "useful": 251913,
            "harmful": 593863
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 461666,
            "TP_to_FN": 314484,
            "TN_to_FP": 0,
            "useful": 461666,
            "harmful": 314484
          },
          "mixed": {
            "FN_to_TP": 395354,
            "FP_to_TN": 608922,
            "TP_to_FN": 631162,
            "TN_to_FP": 1004078,
            "useful": 1004276,
            "harmful": 1635240
          }
        }
      },
      "W/P1/SG15-A075": {
        "region_quality": {
          "foreground_regions_per_image": 16.336734693877553,
          "region_precision": 0.9084322298563398,
          "region_recall": 0.8983323038912909,
          "region_f1": 0.9033540372670807,
          "oracle_positive_regions_missed": 823,
          "oracle_negative_regions_selected": 733,
          "oracle_positive_regions": 8095
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 17.751020408163264,
          "region_precision": 0.8721545182800644,
          "region_recall": 0.9371216800494132,
          "region_f1": 0.9034716846305008,
          "oracle_positive_regions_missed": 509,
          "oracle_negative_regions_selected": 1112,
          "oracle_positive_regions": 8095
        },
        "unrefined_mean_image_iou": 0.8032513708155546,
        "refined_mean_image_iou": 0.7854716886351876,
        "oracle_gap_before": 0.08263119657734275,
        "oracle_gap_after": 0.10041087875770982,
        "fraction_oracle_gap_closed": -0.21516912397275165,
        "changes": {
          "all": {
            "FN_to_TP": 251913,
            "FP_to_TN": 2005760,
            "TP_to_FN": 2414370,
            "TN_to_FP": 593863,
            "useful": 2257673,
            "harmful": 3008233
          },
          "high_FG": {
            "FN_to_TP": 251913,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 593863,
            "useful": 251913,
            "harmful": 593863
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 461666,
            "TP_to_FN": 314484,
            "TN_to_FP": 0,
            "useful": 461666,
            "harmful": 314484
          },
          "mixed": {
            "FN_to_TP": 0,
            "FP_to_TN": 1544094,
            "TP_to_FN": 2099886,
            "TN_to_FP": 0,
            "useful": 1544094,
            "harmful": 2099886
          }
        }
      },
      "W/P1/SG15-B": {
        "region_quality": {
          "foreground_regions_per_image": 17.751020408163264,
          "region_precision": 0.8721545182800644,
          "region_recall": 0.9371216800494132,
          "region_f1": 0.9034716846305008,
          "oracle_positive_regions_missed": 509,
          "oracle_negative_regions_selected": 1112,
          "oracle_positive_regions": 8095
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 17.751020408163264,
          "region_precision": 0.8721545182800644,
          "region_recall": 0.9371216800494132,
          "region_f1": 0.9034716846305008,
          "oracle_positive_regions_missed": 509,
          "oracle_negative_regions_selected": 1112,
          "oracle_positive_regions": 8095
        },
        "unrefined_mean_image_iou": 0.8032513708155546,
        "refined_mean_image_iou": 0.7999224782776669,
        "oracle_gap_before": 0.08263119657734275,
        "oracle_gap_after": 0.08596008911523045,
        "fraction_oracle_gap_closed": -0.040286147070033834,
        "changes": {
          "all": {
            "FN_to_TP": 251913,
            "FP_to_TN": 461666,
            "TP_to_FN": 314484,
            "TN_to_FP": 593863,
            "useful": 713579,
            "harmful": 908347
          },
          "high_FG": {
            "FN_to_TP": 251913,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 593863,
            "useful": 251913,
            "harmful": 593863
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 461666,
            "TP_to_FN": 314484,
            "TN_to_FP": 0,
            "useful": 461666,
            "harmful": 314484
          },
          "mixed": {
            "FN_to_TP": 0,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 0,
            "useful": 0,
            "harmful": 0
          }
        }
      },
      "W/SG11/trim20/rho0p80/SG15-A025": {
        "region_quality": {
          "foreground_regions_per_image": 19.055102040816326,
          "region_precision": 0.8296026560993895,
          "region_recall": 0.956886967263743,
          "region_f1": 0.8887104176227627,
          "oracle_positive_regions_missed": 349,
          "oracle_negative_regions_selected": 1591,
          "oracle_positive_regions": 8095
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 17.675510204081633,
          "region_precision": 0.8725320401801178,
          "region_recall": 0.9335392217418159,
          "region_f1": 0.9020052518500836,
          "oracle_positive_regions_missed": 538,
          "oracle_negative_regions_selected": 1104,
          "oracle_positive_regions": 8095
        },
        "unrefined_mean_image_iou": 0.7974127767071819,
        "refined_mean_image_iou": 0.7703387745120729,
        "oracle_gap_before": 0.08846979068571548,
        "oracle_gap_after": 0.1155437928808245,
        "fraction_oracle_gap_closed": -0.30602538996941986,
        "changes": {
          "all": {
            "FN_to_TP": 1512331,
            "FP_to_TN": 534280,
            "TP_to_FN": 330144,
            "TN_to_FP": 3480200,
            "useful": 2046611,
            "harmful": 3810344
          },
          "high_FG": {
            "FN_to_TP": 379068,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 582409,
            "useful": 379068,
            "harmful": 582409
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 534280,
            "TP_to_FN": 330144,
            "TN_to_FP": 0,
            "useful": 534280,
            "harmful": 330144
          },
          "mixed": {
            "FN_to_TP": 1133263,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 2897791,
            "useful": 1133263,
            "harmful": 2897791
          }
        }
      },
      "W/SG11/trim20/rho0p80/SG15-A050": {
        "region_quality": {
          "foreground_regions_per_image": 17.675510204081633,
          "region_precision": 0.8725320401801178,
          "region_recall": 0.9335392217418159,
          "region_f1": 0.9020052518500836,
          "oracle_positive_regions_missed": 538,
          "oracle_negative_regions_selected": 1104,
          "oracle_positive_regions": 8095
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 17.675510204081633,
          "region_precision": 0.8725320401801178,
          "region_recall": 0.9335392217418159,
          "region_f1": 0.9020052518500836,
          "oracle_positive_regions_missed": 538,
          "oracle_negative_regions_selected": 1104,
          "oracle_positive_regions": 8095
        },
        "unrefined_mean_image_iou": 0.7974127767071819,
        "refined_mean_image_iou": 0.7863106949155261,
        "oracle_gap_before": 0.08846979068571548,
        "oracle_gap_after": 0.09957187247737131,
        "fraction_oracle_gap_closed": -0.1254900876966628,
        "changes": {
          "all": {
            "FN_to_TP": 822700,
            "FP_to_TN": 1281364,
            "TP_to_FN": 1067096,
            "TN_to_FP": 1675179,
            "useful": 2104064,
            "harmful": 2742275
          },
          "high_FG": {
            "FN_to_TP": 379068,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 582409,
            "useful": 379068,
            "harmful": 582409
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 534280,
            "TP_to_FN": 330144,
            "TN_to_FP": 0,
            "useful": 534280,
            "harmful": 330144
          },
          "mixed": {
            "FN_to_TP": 443632,
            "FP_to_TN": 747084,
            "TP_to_FN": 736952,
            "TN_to_FP": 1092770,
            "useful": 1190716,
            "harmful": 1829722
          }
        }
      },
      "W/SG11/trim20/rho0p80/SG15-A075": {
        "region_quality": {
          "foreground_regions_per_image": 16.13877551020408,
          "region_precision": 0.9124936772888215,
          "region_recall": 0.8914144533662754,
          "region_f1": 0.9018309067049929,
          "oracle_positive_regions_missed": 879,
          "oracle_negative_regions_selected": 692,
          "oracle_positive_regions": 8095
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 17.675510204081633,
          "region_precision": 0.8725320401801178,
          "region_recall": 0.9335392217418159,
          "region_f1": 0.9020052518500836,
          "oracle_positive_regions_missed": 538,
          "oracle_negative_regions_selected": 1104,
          "oracle_positive_regions": 8095
        },
        "unrefined_mean_image_iou": 0.7974127767071819,
        "refined_mean_image_iou": 0.7836385790866278,
        "oracle_gap_before": 0.08846979068571548,
        "oracle_gap_after": 0.10224398830626957,
        "fraction_oracle_gap_closed": -0.15569379687453141,
        "changes": {
          "all": {
            "FN_to_TP": 379068,
            "FP_to_TN": 2395582,
            "TP_to_FN": 2611356,
            "TN_to_FP": 582409,
            "useful": 2774650,
            "harmful": 3193765
          },
          "high_FG": {
            "FN_to_TP": 379068,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 582409,
            "useful": 379068,
            "harmful": 582409
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 534280,
            "TP_to_FN": 330144,
            "TN_to_FP": 0,
            "useful": 534280,
            "harmful": 330144
          },
          "mixed": {
            "FN_to_TP": 0,
            "FP_to_TN": 1861302,
            "TP_to_FN": 2281212,
            "TN_to_FP": 0,
            "useful": 1861302,
            "harmful": 2281212
          }
        }
      },
      "W/SG11/trim20/rho0p80/SG15-B": {
        "region_quality": {
          "foreground_regions_per_image": 17.675510204081633,
          "region_precision": 0.8725320401801178,
          "region_recall": 0.9335392217418159,
          "region_f1": 0.9020052518500836,
          "oracle_positive_regions_missed": 538,
          "oracle_negative_regions_selected": 1104,
          "oracle_positive_regions": 8095
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 17.675510204081633,
          "region_precision": 0.8725320401801178,
          "region_recall": 0.9335392217418159,
          "region_f1": 0.9020052518500836,
          "oracle_positive_regions_missed": 538,
          "oracle_negative_regions_selected": 1104,
          "oracle_positive_regions": 8095
        },
        "unrefined_mean_image_iou": 0.7974127767071819,
        "refined_mean_image_iou": 0.7977207391849875,
        "oracle_gap_before": 0.08846979068571548,
        "oracle_gap_after": 0.08816182820790985,
        "fraction_oracle_gap_closed": 0.003480990238799645,
        "changes": {
          "all": {
            "FN_to_TP": 379068,
            "FP_to_TN": 534280,
            "TP_to_FN": 330144,
            "TN_to_FP": 582409,
            "useful": 913348,
            "harmful": 912553
          },
          "high_FG": {
            "FN_to_TP": 379068,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 582409,
            "useful": 379068,
            "harmful": 582409
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 534280,
            "TP_to_FN": 330144,
            "TN_to_FP": 0,
            "useful": 534280,
            "harmful": 330144
          },
          "mixed": {
            "FN_to_TP": 0,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 0,
            "useful": 0,
            "harmful": 0
          }
        }
      },
      "W/SG12/top50/SG15-A025": {
        "region_quality": {
          "foreground_regions_per_image": 18.959183673469386,
          "region_precision": 0.8313240043057051,
          "region_recall": 0.9540457072266831,
          "region_f1": 0.8884670693126259,
          "oracle_positive_regions_missed": 372,
          "oracle_negative_regions_selected": 1567,
          "oracle_positive_regions": 8095
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 17.744897959183675,
          "region_precision": 0.8700402530189765,
          "region_recall": 0.9345274861025324,
          "region_f1": 0.901131625967838,
          "oracle_positive_regions_missed": 530,
          "oracle_negative_regions_selected": 1130,
          "oracle_positive_regions": 8095
        },
        "unrefined_mean_image_iou": 0.8005040675344561,
        "refined_mean_image_iou": 0.771210115119426,
        "oracle_gap_before": 0.08537849985844126,
        "oracle_gap_after": 0.11467245227347134,
        "fraction_oracle_gap_closed": -0.34310690002283784,
        "changes": {
          "all": {
            "FN_to_TP": 1349321,
            "FP_to_TN": 537205,
            "TP_to_FN": 310205,
            "TN_to_FP": 3215017,
            "useful": 1886526,
            "harmful": 3525222
          },
          "high_FG": {
            "FN_to_TP": 286570,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 606790,
            "useful": 286570,
            "harmful": 606790
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 537205,
            "TP_to_FN": 310205,
            "TN_to_FP": 4080,
            "useful": 537205,
            "harmful": 314285
          },
          "mixed": {
            "FN_to_TP": 1062751,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 2604147,
            "useful": 1062751,
            "harmful": 2604147
          }
        }
      },
      "W/SG12/top50/SG15-A050": {
        "region_quality": {
          "foreground_regions_per_image": 17.744897959183675,
          "region_precision": 0.8700402530189765,
          "region_recall": 0.9345274861025324,
          "region_f1": 0.901131625967838,
          "oracle_positive_regions_missed": 530,
          "oracle_negative_regions_selected": 1130,
          "oracle_positive_regions": 8095
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 17.744897959183675,
          "region_precision": 0.8700402530189765,
          "region_recall": 0.9345274861025324,
          "region_f1": 0.901131625967838,
          "oracle_positive_regions_missed": 530,
          "oracle_negative_regions_selected": 1130,
          "oracle_positive_regions": 8095
        },
        "unrefined_mean_image_iou": 0.8005040675344561,
        "refined_mean_image_iou": 0.7869587018709261,
        "oracle_gap_before": 0.08537849985844126,
        "oracle_gap_after": 0.0989238655219713,
        "fraction_oracle_gap_closed": -0.15865078077019912,
        "changes": {
          "all": {
            "FN_to_TP": 749816,
            "FP_to_TN": 1126662,
            "TP_to_FN": 981458,
            "TN_to_FP": 1637792,
            "useful": 1876478,
            "harmful": 2619250
          },
          "high_FG": {
            "FN_to_TP": 286570,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 606790,
            "useful": 286570,
            "harmful": 606790
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 538482,
            "TP_to_FN": 310288,
            "TN_to_FP": 0,
            "useful": 538482,
            "harmful": 310288
          },
          "mixed": {
            "FN_to_TP": 463246,
            "FP_to_TN": 588180,
            "TP_to_FN": 671170,
            "TN_to_FP": 1031002,
            "useful": 1051426,
            "harmful": 1702172
          }
        }
      },
      "W/SG12/top50/SG15-A075": {
        "region_quality": {
          "foreground_regions_per_image": 16.261224489795918,
          "region_precision": 0.9097640562248996,
          "region_recall": 0.8954910438542311,
          "region_f1": 0.9025711261906245,
          "oracle_positive_regions_missed": 846,
          "oracle_negative_regions_selected": 719,
          "oracle_positive_regions": 8095
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 17.744897959183675,
          "region_precision": 0.8700402530189765,
          "region_recall": 0.9345274861025324,
          "region_f1": 0.901131625967838,
          "oracle_positive_regions_missed": 530,
          "oracle_negative_regions_selected": 1130,
          "oracle_positive_regions": 8095
        },
        "unrefined_mean_image_iou": 0.8005040675344561,
        "refined_mean_image_iou": 0.784793672557623,
        "oracle_gap_before": 0.08537849985844126,
        "oracle_gap_after": 0.10108889483527439,
        "fraction_oracle_gap_closed": -0.1840087961592343,
        "changes": {
          "all": {
            "FN_to_TP": 286570,
            "FP_to_TN": 2142343,
            "TP_to_FN": 2556073,
            "TN_to_FP": 606790,
            "useful": 2428913,
            "harmful": 3162863
          },
          "high_FG": {
            "FN_to_TP": 286570,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 606790,
            "useful": 286570,
            "harmful": 606790
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 538482,
            "TP_to_FN": 310288,
            "TN_to_FP": 0,
            "useful": 538482,
            "harmful": 310288
          },
          "mixed": {
            "FN_to_TP": 0,
            "FP_to_TN": 1603861,
            "TP_to_FN": 2245785,
            "TN_to_FP": 0,
            "useful": 1603861,
            "harmful": 2245785
          }
        }
      },
      "W/SG12/top50/SG15-B": {
        "region_quality": {
          "foreground_regions_per_image": 17.744897959183675,
          "region_precision": 0.8700402530189765,
          "region_recall": 0.9345274861025324,
          "region_f1": 0.901131625967838,
          "oracle_positive_regions_missed": 530,
          "oracle_negative_regions_selected": 1130,
          "oracle_positive_regions": 8095
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 17.744897959183675,
          "region_precision": 0.8700402530189765,
          "region_recall": 0.9345274861025324,
          "region_f1": 0.901131625967838,
          "oracle_positive_regions_missed": 530,
          "oracle_negative_regions_selected": 1130,
          "oracle_positive_regions": 8095
        },
        "unrefined_mean_image_iou": 0.8005040675344561,
        "refined_mean_image_iou": 0.798835914290351,
        "oracle_gap_before": 0.08537849985844126,
        "oracle_gap_after": 0.08704665310254645,
        "fraction_oracle_gap_closed": -0.019538329285136272,
        "changes": {
          "all": {
            "FN_to_TP": 286570,
            "FP_to_TN": 538482,
            "TP_to_FN": 310288,
            "TN_to_FP": 606790,
            "useful": 825052,
            "harmful": 917078
          },
          "high_FG": {
            "FN_to_TP": 286570,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 606790,
            "useful": 286570,
            "harmful": 606790
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 538482,
            "TP_to_FN": 310288,
            "TN_to_FP": 0,
            "useful": 538482,
            "harmful": 310288
          },
          "mixed": {
            "FN_to_TP": 0,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 0,
            "useful": 0,
            "harmful": 0
          }
        }
      }
    }
  },
  "coco": {
    "oracle_mean_image_iou": 0.805229982393218,
    "legacy_SG13_nearest64_GT_oracle_mean_image_iou": 0.7946008680974529,
    "oracle_note": "Main diagnostic GT fractions are evaluated over annotation-resolution regions, as are prior occupancies. Legacy nearest64-GT SG13 oracle is also retained, never used by prediction.",
    "region_selected_definition": "at least 50% output occupancy in nonempty region; for majority projection equals its chosen label, for B a diagnostic summary of mixed regions",
    "cells": {
      "W/P1/SG15-A025": {
        "region_quality": {
          "foreground_regions_per_image": 14.885431400282885,
          "region_precision": 0.6313188901558343,
          "region_recall": 0.9397454031117397,
          "region_f1": 0.755257474138911,
          "oracle_positive_regions_missed": 426,
          "oracle_negative_regions_selected": 3880,
          "oracle_positive_regions": 7070
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 13.582743988684582,
          "region_precision": 0.6772883473914402,
          "region_recall": 0.9199434229137199,
          "region_f1": 0.7801835302585018,
          "oracle_positive_regions_missed": 566,
          "oracle_negative_regions_selected": 3099,
          "oracle_positive_regions": 7070
        },
        "unrefined_mean_image_iou": 0.6510521253313133,
        "refined_mean_image_iou": 0.6049967878747269,
        "oracle_gap_before": 0.15417785706190468,
        "oracle_gap_after": 0.2002331945184911,
        "fraction_oracle_gap_closed": -0.29871564136537787,
        "changes": {
          "all": {
            "FN_to_TP": 1113108,
            "FP_to_TN": 955833,
            "TP_to_FN": 326916,
            "TN_to_FP": 5576127,
            "useful": 2068941,
            "harmful": 5903043
          },
          "high_FG": {
            "FN_to_TP": 221748,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 925494,
            "useful": 221748,
            "harmful": 925494
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 955833,
            "TP_to_FN": 326916,
            "TN_to_FP": 5568,
            "useful": 955833,
            "harmful": 332484
          },
          "mixed": {
            "FN_to_TP": 891360,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 4645065,
            "useful": 891360,
            "harmful": 4645065
          }
        }
      },
      "W/P1/SG15-A050": {
        "region_quality": {
          "foreground_regions_per_image": 13.582743988684582,
          "region_precision": 0.6772883473914402,
          "region_recall": 0.9199434229137199,
          "region_f1": 0.7801835302585018,
          "oracle_positive_regions_missed": 566,
          "oracle_negative_regions_selected": 3099,
          "oracle_positive_regions": 7070
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 13.582743988684582,
          "region_precision": 0.6772883473914402,
          "region_recall": 0.9199434229137199,
          "region_f1": 0.7801835302585018,
          "oracle_positive_regions_missed": 566,
          "oracle_negative_regions_selected": 3099,
          "oracle_positive_regions": 7070
        },
        "unrefined_mean_image_iou": 0.6510521253313133,
        "refined_mean_image_iou": 0.6300131624982073,
        "oracle_gap_before": 0.15417785706190468,
        "oracle_gap_after": 0.1752168198950107,
        "fraction_oracle_gap_closed": -0.1364590430431172,
        "changes": {
          "all": {
            "FN_to_TP": 550040,
            "FP_to_TN": 2257263,
            "TP_to_FN": 1073358,
            "TN_to_FP": 2710459,
            "useful": 2807303,
            "harmful": 3783817
          },
          "high_FG": {
            "FN_to_TP": 221748,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 925494,
            "useful": 221748,
            "harmful": 925494
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 957689,
            "TP_to_FN": 326916,
            "TN_to_FP": 0,
            "useful": 957689,
            "harmful": 326916
          },
          "mixed": {
            "FN_to_TP": 328292,
            "FP_to_TN": 1299574,
            "TP_to_FN": 746442,
            "TN_to_FP": 1784965,
            "useful": 1627866,
            "harmful": 2531407
          }
        }
      },
      "W/P1/SG15-A075": {
        "region_quality": {
          "foreground_regions_per_image": 12.091937765205092,
          "region_precision": 0.7248801029360159,
          "region_recall": 0.8765205091937766,
          "region_f1": 0.79352071195339,
          "oracle_positive_regions_missed": 873,
          "oracle_negative_regions_selected": 2352,
          "oracle_positive_regions": 7070
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 13.582743988684582,
          "region_precision": 0.6772883473914402,
          "region_recall": 0.9199434229137199,
          "region_f1": 0.7801835302585018,
          "oracle_positive_regions_missed": 566,
          "oracle_negative_regions_selected": 3099,
          "oracle_positive_regions": 7070
        },
        "unrefined_mean_image_iou": 0.6510521253313133,
        "refined_mean_image_iou": 0.635342153487434,
        "oracle_gap_before": 0.15417785706190468,
        "oracle_gap_after": 0.16988782890578402,
        "fraction_oracle_gap_closed": -0.10189512387353755,
        "changes": {
          "all": {
            "FN_to_TP": 221748,
            "FP_to_TN": 4267438,
            "TP_to_FN": 2647910,
            "TN_to_FP": 925494,
            "useful": 4489186,
            "harmful": 3573404
          },
          "high_FG": {
            "FN_to_TP": 221748,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 925494,
            "useful": 221748,
            "harmful": 925494
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 957689,
            "TP_to_FN": 326916,
            "TN_to_FP": 0,
            "useful": 957689,
            "harmful": 326916
          },
          "mixed": {
            "FN_to_TP": 0,
            "FP_to_TN": 3309749,
            "TP_to_FN": 2320994,
            "TN_to_FP": 0,
            "useful": 3309749,
            "harmful": 2320994
          }
        }
      },
      "W/P1/SG15-B": {
        "region_quality": {
          "foreground_regions_per_image": 13.582743988684582,
          "region_precision": 0.6772883473914402,
          "region_recall": 0.9199434229137199,
          "region_f1": 0.7801835302585018,
          "oracle_positive_regions_missed": 566,
          "oracle_negative_regions_selected": 3099,
          "oracle_positive_regions": 7070
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 13.582743988684582,
          "region_precision": 0.6772883473914402,
          "region_recall": 0.9199434229137199,
          "region_f1": 0.7801835302585018,
          "oracle_positive_regions_missed": 566,
          "oracle_negative_regions_selected": 3099,
          "oracle_positive_regions": 7070
        },
        "unrefined_mean_image_iou": 0.6510521253313133,
        "refined_mean_image_iou": 0.6477144885820664,
        "oracle_gap_before": 0.15417785706190468,
        "oracle_gap_after": 0.1575154938111516,
        "fraction_oracle_gap_closed": -0.02164796432412995,
        "changes": {
          "all": {
            "FN_to_TP": 221748,
            "FP_to_TN": 957689,
            "TP_to_FN": 326916,
            "TN_to_FP": 925494,
            "useful": 1179437,
            "harmful": 1252410
          },
          "high_FG": {
            "FN_to_TP": 221748,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 925494,
            "useful": 221748,
            "harmful": 925494
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 957689,
            "TP_to_FN": 326916,
            "TN_to_FP": 0,
            "useful": 957689,
            "harmful": 326916
          },
          "mixed": {
            "FN_to_TP": 0,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 0,
            "useful": 0,
            "harmful": 0
          }
        }
      },
      "W/SG11/trim20/rho0p80/SG15-A025": {
        "region_quality": {
          "foreground_regions_per_image": 14.478076379066477,
          "region_precision": 0.6414615084017194,
          "region_recall": 0.9287128712871288,
          "region_f1": 0.7588119727262223,
          "oracle_positive_regions_missed": 504,
          "oracle_negative_regions_selected": 3670,
          "oracle_positive_regions": 7070
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 13.033946251768034,
          "region_precision": 0.6906131307650569,
          "region_recall": 0.9001414427157002,
          "region_f1": 0.7815781393920785,
          "oracle_positive_regions_missed": 706,
          "oracle_negative_regions_selected": 2851,
          "oracle_positive_regions": 7070
        },
        "unrefined_mean_image_iou": 0.6521182759251232,
        "refined_mean_image_iou": 0.6100519534912684,
        "oracle_gap_before": 0.1531117064680948,
        "oracle_gap_after": 0.19517802890194957,
        "fraction_oracle_gap_closed": -0.27474269214431685,
        "changes": {
          "all": {
            "FN_to_TP": 1507135,
            "FP_to_TN": 1043795,
            "TP_to_FN": 378723,
            "TN_to_FP": 5826791,
            "useful": 2550930,
            "harmful": 6205514
          },
          "high_FG": {
            "FN_to_TP": 334146,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 966912,
            "useful": 334146,
            "harmful": 966912
          },
          "high_BG": {
            "FN_to_TP": 4942,
            "FP_to_TN": 1043795,
            "TP_to_FN": 378723,
            "TN_to_FP": 1634,
            "useful": 1048737,
            "harmful": 380357
          },
          "mixed": {
            "FN_to_TP": 1168047,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 4858245,
            "useful": 1168047,
            "harmful": 4858245
          }
        }
      },
      "W/SG11/trim20/rho0p80/SG15-A050": {
        "region_quality": {
          "foreground_regions_per_image": 13.033946251768034,
          "region_precision": 0.6906131307650569,
          "region_recall": 0.9001414427157002,
          "region_f1": 0.7815781393920785,
          "oracle_positive_regions_missed": 706,
          "oracle_negative_regions_selected": 2851,
          "oracle_positive_regions": 7070
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 13.033946251768034,
          "region_precision": 0.6906131307650569,
          "region_recall": 0.9001414427157002,
          "region_f1": 0.7815781393920785,
          "oracle_positive_regions_missed": 706,
          "oracle_negative_regions_selected": 2851,
          "oracle_positive_regions": 7070
        },
        "unrefined_mean_image_iou": 0.6521182759251232,
        "refined_mean_image_iou": 0.6329536610472555,
        "oracle_gap_before": 0.1531117064680948,
        "oracle_gap_after": 0.1722763213459625,
        "fraction_oracle_gap_closed": -0.12516753499747055,
        "changes": {
          "all": {
            "FN_to_TP": 787369,
            "FP_to_TN": 2423526,
            "TP_to_FN": 1247126,
            "TN_to_FP": 2737155,
            "useful": 3210895,
            "harmful": 3984281
          },
          "high_FG": {
            "FN_to_TP": 334146,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 966912,
            "useful": 334146,
            "harmful": 966912
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 1044049,
            "TP_to_FN": 380661,
            "TN_to_FP": 0,
            "useful": 1044049,
            "harmful": 380661
          },
          "mixed": {
            "FN_to_TP": 453223,
            "FP_to_TN": 1379477,
            "TP_to_FN": 866465,
            "TN_to_FP": 1770243,
            "useful": 1832700,
            "harmful": 2636708
          }
        }
      },
      "W/SG11/trim20/rho0p80/SG15-A075": {
        "region_quality": {
          "foreground_regions_per_image": 11.516265912305517,
          "region_precision": 0.7397445345124048,
          "region_recall": 0.8519094766619519,
          "region_f1": 0.7918748356560611,
          "oracle_positive_regions_missed": 1047,
          "oracle_negative_regions_selected": 2119,
          "oracle_positive_regions": 7070
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 13.033946251768034,
          "region_precision": 0.6906131307650569,
          "region_recall": 0.9001414427157002,
          "region_f1": 0.7815781393920785,
          "oracle_positive_regions_missed": 706,
          "oracle_negative_regions_selected": 2851,
          "oracle_positive_regions": 7070
        },
        "unrefined_mean_image_iou": 0.6521182759251232,
        "refined_mean_image_iou": 0.634529737070215,
        "oracle_gap_before": 0.1531117064680948,
        "oracle_gap_after": 0.17070024532300299,
        "fraction_oracle_gap_closed": -0.11487389998212358,
        "changes": {
          "all": {
            "FN_to_TP": 334146,
            "FP_to_TN": 4509727,
            "TP_to_FN": 2943603,
            "TN_to_FP": 966912,
            "useful": 4843873,
            "harmful": 3910515
          },
          "high_FG": {
            "FN_to_TP": 334146,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 966912,
            "useful": 334146,
            "harmful": 966912
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 1044049,
            "TP_to_FN": 380661,
            "TN_to_FP": 0,
            "useful": 1044049,
            "harmful": 380661
          },
          "mixed": {
            "FN_to_TP": 0,
            "FP_to_TN": 3465678,
            "TP_to_FN": 2562942,
            "TN_to_FP": 0,
            "useful": 3465678,
            "harmful": 2562942
          }
        }
      },
      "W/SG11/trim20/rho0p80/SG15-B": {
        "region_quality": {
          "foreground_regions_per_image": 13.033946251768034,
          "region_precision": 0.6906131307650569,
          "region_recall": 0.9001414427157002,
          "region_f1": 0.7815781393920785,
          "oracle_positive_regions_missed": 706,
          "oracle_negative_regions_selected": 2851,
          "oracle_positive_regions": 7070
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 13.033946251768034,
          "region_precision": 0.6906131307650569,
          "region_recall": 0.9001414427157002,
          "region_f1": 0.7815781393920785,
          "oracle_positive_regions_missed": 706,
          "oracle_negative_regions_selected": 2851,
          "oracle_positive_regions": 7070
        },
        "unrefined_mean_image_iou": 0.6521182759251232,
        "refined_mean_image_iou": 0.6512791449053763,
        "oracle_gap_before": 0.1531117064680948,
        "oracle_gap_after": 0.15395083748784166,
        "fraction_oracle_gap_closed": -0.0054805151030154625,
        "changes": {
          "all": {
            "FN_to_TP": 334146,
            "FP_to_TN": 1044049,
            "TP_to_FN": 380661,
            "TN_to_FP": 966912,
            "useful": 1378195,
            "harmful": 1347573
          },
          "high_FG": {
            "FN_to_TP": 334146,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 966912,
            "useful": 334146,
            "harmful": 966912
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 1044049,
            "TP_to_FN": 380661,
            "TN_to_FP": 0,
            "useful": 1044049,
            "harmful": 380661
          },
          "mixed": {
            "FN_to_TP": 0,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 0,
            "useful": 0,
            "harmful": 0
          }
        }
      },
      "W/SG12/top50/SG15-A025": {
        "region_quality": {
          "foreground_regions_per_image": 14.782178217821782,
          "region_precision": 0.6351545306669218,
          "region_recall": 0.9388967468175389,
          "region_f1": 0.7577193082586612,
          "oracle_positive_regions_missed": 432,
          "oracle_negative_regions_selected": 3813,
          "oracle_positive_regions": 7070
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 13.346534653465346,
          "region_precision": 0.6867316659601526,
          "region_recall": 0.9165487977369166,
          "region_f1": 0.7851690294438386,
          "oracle_positive_regions_missed": 590,
          "oracle_negative_regions_selected": 2956,
          "oracle_positive_regions": 7070
        },
        "unrefined_mean_image_iou": 0.6514281579666902,
        "refined_mean_image_iou": 0.605314291741782,
        "oracle_gap_before": 0.1538018244265278,
        "oracle_gap_after": 0.199915690651436,
        "fraction_oracle_gap_closed": -0.29982652284425354,
        "changes": {
          "all": {
            "FN_to_TP": 1263859,
            "FP_to_TN": 1016077,
            "TP_to_FN": 339874,
            "TN_to_FP": 5941969,
            "useful": 2279936,
            "harmful": 6281843
          },
          "high_FG": {
            "FN_to_TP": 247809,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 929788,
            "useful": 247809,
            "harmful": 929788
          },
          "high_BG": {
            "FN_to_TP": 1143,
            "FP_to_TN": 1016077,
            "TP_to_FN": 339874,
            "TN_to_FP": 5289,
            "useful": 1017220,
            "harmful": 345163
          },
          "mixed": {
            "FN_to_TP": 1014907,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 5006892,
            "useful": 1014907,
            "harmful": 5006892
          }
        }
      },
      "W/SG12/top50/SG15-A050": {
        "region_quality": {
          "foreground_regions_per_image": 13.346534653465346,
          "region_precision": 0.6867316659601526,
          "region_recall": 0.9165487977369166,
          "region_f1": 0.7851690294438386,
          "oracle_positive_regions_missed": 590,
          "oracle_negative_regions_selected": 2956,
          "oracle_positive_regions": 7070
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 13.346534653465346,
          "region_precision": 0.6867316659601526,
          "region_recall": 0.9165487977369166,
          "region_f1": 0.7851690294438386,
          "oracle_positive_regions_missed": 590,
          "oracle_negative_regions_selected": 2956,
          "oracle_positive_regions": 7070
        },
        "unrefined_mean_image_iou": 0.6514281579666902,
        "refined_mean_image_iou": 0.6325272435170017,
        "oracle_gap_before": 0.1538018244265278,
        "oracle_gap_after": 0.17270273887621623,
        "fraction_oracle_gap_closed": -0.12289135398857082,
        "changes": {
          "all": {
            "FN_to_TP": 651942,
            "FP_to_TN": 2505901,
            "TP_to_FN": 1140368,
            "TN_to_FP": 2728044,
            "useful": 3157843,
            "harmful": 3868412
          },
          "high_FG": {
            "FN_to_TP": 247809,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 929788,
            "useful": 247809,
            "harmful": 929788
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 1016516,
            "TP_to_FN": 341579,
            "TN_to_FP": 0,
            "useful": 1016516,
            "harmful": 341579
          },
          "mixed": {
            "FN_to_TP": 404133,
            "FP_to_TN": 1489385,
            "TP_to_FN": 798789,
            "TN_to_FP": 1798256,
            "useful": 1893518,
            "harmful": 2597045
          }
        }
      },
      "W/SG12/top50/SG15-A075": {
        "region_quality": {
          "foreground_regions_per_image": 11.847241867043847,
          "region_precision": 0.7349570200573066,
          "region_recall": 0.8707213578500708,
          "region_f1": 0.7970995727049074,
          "oracle_positive_regions_missed": 914,
          "oracle_negative_regions_selected": 2220,
          "oracle_positive_regions": 7070
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 13.346534653465346,
          "region_precision": 0.6867316659601526,
          "region_recall": 0.9165487977369166,
          "region_f1": 0.7851690294438386,
          "oracle_positive_regions_missed": 590,
          "oracle_negative_regions_selected": 2956,
          "oracle_positive_regions": 7070
        },
        "unrefined_mean_image_iou": 0.6514281579666902,
        "refined_mean_image_iou": 0.6362153078436461,
        "oracle_gap_before": 0.1538018244265278,
        "oracle_gap_after": 0.16901467454957186,
        "fraction_oracle_gap_closed": -0.09891202643250412,
        "changes": {
          "all": {
            "FN_to_TP": 247809,
            "FP_to_TN": 4530175,
            "TP_to_FN": 2824105,
            "TN_to_FP": 929788,
            "useful": 4777984,
            "harmful": 3753893
          },
          "high_FG": {
            "FN_to_TP": 247809,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 929788,
            "useful": 247809,
            "harmful": 929788
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 1016516,
            "TP_to_FN": 341579,
            "TN_to_FP": 0,
            "useful": 1016516,
            "harmful": 341579
          },
          "mixed": {
            "FN_to_TP": 0,
            "FP_to_TN": 3513659,
            "TP_to_FN": 2482526,
            "TN_to_FP": 0,
            "useful": 3513659,
            "harmful": 2482526
          }
        }
      },
      "W/SG12/top50/SG15-B": {
        "region_quality": {
          "foreground_regions_per_image": 13.346534653465346,
          "region_precision": 0.6867316659601526,
          "region_recall": 0.9165487977369166,
          "region_f1": 0.7851690294438386,
          "oracle_positive_regions_missed": 590,
          "oracle_negative_regions_selected": 2956,
          "oracle_positive_regions": 7070
        },
        "prior_region_quality": {
          "foreground_regions_per_image": 13.346534653465346,
          "region_precision": 0.6867316659601526,
          "region_recall": 0.9165487977369166,
          "region_f1": 0.7851690294438386,
          "oracle_positive_regions_missed": 590,
          "oracle_negative_regions_selected": 2956,
          "oracle_positive_regions": 7070
        },
        "unrefined_mean_image_iou": 0.6514281579666902,
        "refined_mean_image_iou": 0.649099841890565,
        "oracle_gap_before": 0.1538018244265278,
        "oracle_gap_after": 0.15613014050265295,
        "fraction_oracle_gap_closed": -0.015138416496726355,
        "changes": {
          "all": {
            "FN_to_TP": 247809,
            "FP_to_TN": 1016516,
            "TP_to_FN": 341579,
            "TN_to_FP": 929788,
            "useful": 1264325,
            "harmful": 1271367
          },
          "high_FG": {
            "FN_to_TP": 247809,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 929788,
            "useful": 247809,
            "harmful": 929788
          },
          "high_BG": {
            "FN_to_TP": 0,
            "FP_to_TN": 1016516,
            "TP_to_FN": 341579,
            "TN_to_FP": 0,
            "useful": 1016516,
            "harmful": 341579
          },
          "mixed": {
            "FN_to_TP": 0,
            "FP_to_TN": 0,
            "TP_to_FN": 0,
            "TN_to_FP": 0,
            "useful": 0,
            "harmful": 0
          }
        }
      }
    }
  }
}
```

## Five folds and forced OOF comparisons

```json
{
  "screens": {
    "W/P1_SG15-A": {
      "reference": "W/P1",
      "candidates": [
        "W/P1/SG15-A025",
        "W/P1/SG15-A050",
        "W/P1/SG15-A075"
      ],
      "folds": [
        {
          "fold": 0,
          "chosen": "W/P1",
          "chosen_threshold": 0.45,
          "reference_threshold": 0.45,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.8004117301197283,
          "train_miou_reference": 0.8004117301197283,
          "heldout_miou_chosen": 0.8043717755713968,
          "heldout_miou_reference": 0.8043717755713968
        },
        {
          "fold": 1,
          "chosen": "W/P1",
          "chosen_threshold": 0.45,
          "reference_threshold": 0.45,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.7944201857039574,
          "train_miou_reference": 0.7944201857039574,
          "heldout_miou_chosen": 0.8236552709257694,
          "heldout_miou_reference": 0.8236552709257694
        },
        {
          "fold": 2,
          "chosen": "W/P1",
          "chosen_threshold": 0.45,
          "reference_threshold": 0.45,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.800918785410665,
          "train_miou_reference": 0.800918785410665,
          "heldout_miou_chosen": 0.8023293971713426,
          "heldout_miou_reference": 0.8023293971713426
        },
        {
          "fold": 3,
          "chosen": "W/P1",
          "chosen_threshold": 0.45,
          "reference_threshold": 0.45,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.803829218401459,
          "train_miou_reference": 0.803829218401459,
          "heldout_miou_chosen": 0.7905416055541602,
          "heldout_miou_reference": 0.7905416055541602
        },
        {
          "fold": 4,
          "chosen": "W/P1",
          "chosen_threshold": 0.475,
          "reference_threshold": 0.475,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.804239812553811,
          "train_miou_reference": 0.804239812553811,
          "heldout_miou_chosen": 0.7818058154631513,
          "heldout_miou_reference": 0.7818058154631513
        }
      ],
      "selection_counts": {
        "W/P1": 5
      },
      "vote_winner": "W/P1",
      "vote_winner_votes": 5,
      "frozen": "W/P1",
      "freeze_reason": "reference won the fold vote",
      "oof_miou_selection": 0.7996523496064184,
      "oof_miou_reference": 0.7996523496064184,
      "oof_gain": 0.0,
      "full_threshold_frozen": 0.45,
      "full_threshold_reference": 0.45,
      "full_miou_frozen": 0.8005846665606157,
      "full_miou_reference": 0.8005846665606157,
      "paired_oof": {
        "mean": 0.0,
        "ci_low": 0.0,
        "ci_high": 0.0,
        "better": 0,
        "worse": 0,
        "ties": 490
      }
    },
    "W/P1_SG15-B": {
      "reference": "W/P1",
      "candidates": [
        "W/P1/SG15-B"
      ],
      "folds": [
        {
          "fold": 0,
          "chosen": "W/P1",
          "chosen_threshold": 0.45,
          "reference_threshold": 0.45,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.8004117301197283,
          "train_miou_reference": 0.8004117301197283,
          "heldout_miou_chosen": 0.8043717755713968,
          "heldout_miou_reference": 0.8043717755713968
        },
        {
          "fold": 1,
          "chosen": "W/P1",
          "chosen_threshold": 0.45,
          "reference_threshold": 0.45,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.7944201857039574,
          "train_miou_reference": 0.7944201857039574,
          "heldout_miou_chosen": 0.8236552709257694,
          "heldout_miou_reference": 0.8236552709257694
        },
        {
          "fold": 2,
          "chosen": "W/P1",
          "chosen_threshold": 0.45,
          "reference_threshold": 0.45,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.800918785410665,
          "train_miou_reference": 0.800918785410665,
          "heldout_miou_chosen": 0.8023293971713426,
          "heldout_miou_reference": 0.8023293971713426
        },
        {
          "fold": 3,
          "chosen": "W/P1",
          "chosen_threshold": 0.45,
          "reference_threshold": 0.45,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.803829218401459,
          "train_miou_reference": 0.803829218401459,
          "heldout_miou_chosen": 0.7905416055541602,
          "heldout_miou_reference": 0.7905416055541602
        },
        {
          "fold": 4,
          "chosen": "W/P1",
          "chosen_threshold": 0.475,
          "reference_threshold": 0.475,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.804239812553811,
          "train_miou_reference": 0.804239812553811,
          "heldout_miou_chosen": 0.7818058154631513,
          "heldout_miou_reference": 0.7818058154631513
        }
      ],
      "selection_counts": {
        "W/P1": 5
      },
      "vote_winner": "W/P1",
      "vote_winner_votes": 5,
      "frozen": "W/P1",
      "freeze_reason": "reference won the fold vote",
      "oof_miou_selection": 0.7996523496064184,
      "oof_miou_reference": 0.7996523496064184,
      "oof_gain": 0.0,
      "full_threshold_frozen": 0.45,
      "full_threshold_reference": 0.45,
      "full_miou_frozen": 0.8005846665606157,
      "full_miou_reference": 0.8005846665606157,
      "paired_oof": {
        "mean": 0.0,
        "ci_low": 0.0,
        "ci_high": 0.0,
        "better": 0,
        "worse": 0,
        "ties": 490
      }
    },
    "W/SG11/trim20/rho0p80_SG15-A": {
      "reference": "W/SG11/trim20/rho0p80",
      "candidates": [
        "W/SG11/trim20/rho0p80/SG15-A025",
        "W/SG11/trim20/rho0p80/SG15-A050",
        "W/SG11/trim20/rho0p80/SG15-A075"
      ],
      "folds": [
        {
          "fold": 0,
          "chosen": "W/SG11/trim20/rho0p80",
          "chosen_threshold": 0.425,
          "reference_threshold": 0.425,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.7988334127115324,
          "train_miou_reference": 0.7988334127115324,
          "heldout_miou_chosen": 0.7981035044997601,
          "heldout_miou_reference": 0.7981035044997601
        },
        {
          "fold": 1,
          "chosen": "W/SG11/trim20/rho0p80",
          "chosen_threshold": 0.425,
          "reference_threshold": 0.425,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.7938446893296913,
          "train_miou_reference": 0.7938446893296913,
          "heldout_miou_chosen": 0.8152177748924299,
          "heldout_miou_reference": 0.8152177748924299
        },
        {
          "fold": 2,
          "chosen": "W/SG11/trim20/rho0p80",
          "chosen_threshold": 0.425,
          "reference_threshold": 0.425,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.798978351866665,
          "train_miou_reference": 0.798978351866665,
          "heldout_miou_chosen": 0.7983786747748505,
          "heldout_miou_reference": 0.7983786747748505
        },
        {
          "fold": 3,
          "chosen": "W/SG11/trim20/rho0p80",
          "chosen_threshold": 0.425,
          "reference_threshold": 0.425,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.7999777499621435,
          "train_miou_reference": 0.7999777499621435,
          "heldout_miou_chosen": 0.7925278595866733,
          "heldout_miou_reference": 0.7925278595866733
        },
        {
          "fold": 4,
          "chosen": "W/SG11/trim20/rho0p80",
          "chosen_threshold": 0.425,
          "reference_threshold": 0.425,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.8001730637613649,
          "train_miou_reference": 0.8001730637613649,
          "heldout_miou_chosen": 0.7859481776989832,
          "heldout_miou_reference": 0.7859481776989832
        }
      ],
      "selection_counts": {
        "W/SG11/trim20/rho0p80": 5
      },
      "vote_winner": "W/SG11/trim20/rho0p80",
      "vote_winner_votes": 5,
      "frozen": "W/SG11/trim20/rho0p80",
      "freeze_reason": "reference won the fold vote",
      "oof_miou_selection": 0.798400027953512,
      "oof_miou_reference": 0.798400027953512,
      "oof_gain": 0.0,
      "full_threshold_frozen": 0.425,
      "full_threshold_reference": 0.425,
      "full_miou_frozen": 0.798400027953512,
      "full_miou_reference": 0.798400027953512,
      "paired_oof": {
        "mean": 0.0,
        "ci_low": 0.0,
        "ci_high": 0.0,
        "better": 0,
        "worse": 0,
        "ties": 490
      }
    },
    "W/SG11/trim20/rho0p80_SG15-B": {
      "reference": "W/SG11/trim20/rho0p80",
      "candidates": [
        "W/SG11/trim20/rho0p80/SG15-B"
      ],
      "folds": [
        {
          "fold": 0,
          "chosen": "W/SG11/trim20/rho0p80",
          "chosen_threshold": 0.425,
          "reference_threshold": 0.425,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.7988334127115324,
          "train_miou_reference": 0.7988334127115324,
          "heldout_miou_chosen": 0.7981035044997601,
          "heldout_miou_reference": 0.7981035044997601
        },
        {
          "fold": 1,
          "chosen": "W/SG11/trim20/rho0p80",
          "chosen_threshold": 0.425,
          "reference_threshold": 0.425,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.7938446893296913,
          "train_miou_reference": 0.7938446893296913,
          "heldout_miou_chosen": 0.8152177748924299,
          "heldout_miou_reference": 0.8152177748924299
        },
        {
          "fold": 2,
          "chosen": "W/SG11/trim20/rho0p80",
          "chosen_threshold": 0.425,
          "reference_threshold": 0.425,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.798978351866665,
          "train_miou_reference": 0.798978351866665,
          "heldout_miou_chosen": 0.7983786747748505,
          "heldout_miou_reference": 0.7983786747748505
        },
        {
          "fold": 3,
          "chosen": "W/SG11/trim20/rho0p80",
          "chosen_threshold": 0.425,
          "reference_threshold": 0.425,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.7999777499621435,
          "train_miou_reference": 0.7999777499621435,
          "heldout_miou_chosen": 0.7925278595866733,
          "heldout_miou_reference": 0.7925278595866733
        },
        {
          "fold": 4,
          "chosen": "W/SG11/trim20/rho0p80",
          "chosen_threshold": 0.425,
          "reference_threshold": 0.425,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.8001730637613649,
          "train_miou_reference": 0.8001730637613649,
          "heldout_miou_chosen": 0.7859481776989832,
          "heldout_miou_reference": 0.7859481776989832
        }
      ],
      "selection_counts": {
        "W/SG11/trim20/rho0p80": 5
      },
      "vote_winner": "W/SG11/trim20/rho0p80",
      "vote_winner_votes": 5,
      "frozen": "W/SG11/trim20/rho0p80",
      "freeze_reason": "reference won the fold vote",
      "oof_miou_selection": 0.798400027953512,
      "oof_miou_reference": 0.798400027953512,
      "oof_gain": 0.0,
      "full_threshold_frozen": 0.425,
      "full_threshold_reference": 0.425,
      "full_miou_frozen": 0.798400027953512,
      "full_miou_reference": 0.798400027953512,
      "paired_oof": {
        "mean": 0.0,
        "ci_low": 0.0,
        "ci_high": 0.0,
        "better": 0,
        "worse": 0,
        "ties": 490
      }
    },
    "W/SG12/top50_SG15-A": {
      "reference": "W/SG12/top50",
      "candidates": [
        "W/SG12/top50/SG15-A025",
        "W/SG12/top50/SG15-A050",
        "W/SG12/top50/SG15-A075"
      ],
      "folds": [
        {
          "fold": 0,
          "chosen": "W/SG12/top50",
          "chosen_threshold": 0.45,
          "reference_threshold": 0.45,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.7993483891359897,
          "train_miou_reference": 0.7993483891359897,
          "heldout_miou_chosen": 0.7980079201556065,
          "heldout_miou_reference": 0.7980079201556065
        },
        {
          "fold": 1,
          "chosen": "W/SG12/top50",
          "chosen_threshold": 0.45,
          "reference_threshold": 0.45,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.792573796601294,
          "train_miou_reference": 0.792573796601294,
          "heldout_miou_chosen": 0.8210694391882276,
          "heldout_miou_reference": 0.8210694391882276
        },
        {
          "fold": 2,
          "chosen": "W/SG12/top50",
          "chosen_threshold": 0.45,
          "reference_threshold": 0.45,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.8000770040354752,
          "train_miou_reference": 0.8000770040354752,
          "heldout_miou_chosen": 0.7957113805320305,
          "heldout_miou_reference": 0.7957113805320305
        },
        {
          "fold": 3,
          "chosen": "W/SG12/top50",
          "chosen_threshold": 0.45,
          "reference_threshold": 0.45,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.8011205136263397,
          "train_miou_reference": 0.8011205136263397,
          "heldout_miou_chosen": 0.7904002140640006,
          "heldout_miou_reference": 0.7904002140640006
        },
        {
          "fold": 4,
          "chosen": "W/SG12/top50",
          "chosen_threshold": 0.475,
          "reference_threshold": 0.475,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.8000199383633966,
          "train_miou_reference": 0.8000199383633966,
          "heldout_miou_chosen": 0.7811817777136335,
          "heldout_miou_reference": 0.7811817777136335
        }
      ],
      "selection_counts": {
        "W/SG12/top50": 5
      },
      "vote_winner": "W/SG12/top50",
      "vote_winner_votes": 5,
      "frozen": "W/SG12/top50",
      "freeze_reason": "reference won the fold vote",
      "oof_miou_selection": 0.796657782422708,
      "oof_miou_reference": 0.796657782422708,
      "oof_gain": 0.0,
      "full_threshold_frozen": 0.45,
      "full_threshold_reference": 0.45,
      "full_miou_frozen": 0.7985584168680424,
      "full_miou_reference": 0.7985584168680424,
      "paired_oof": {
        "mean": 0.0,
        "ci_low": 0.0,
        "ci_high": 0.0,
        "better": 0,
        "worse": 0,
        "ties": 490
      }
    },
    "W/SG12/top50_SG15-B": {
      "reference": "W/SG12/top50",
      "candidates": [
        "W/SG12/top50/SG15-B"
      ],
      "folds": [
        {
          "fold": 0,
          "chosen": "W/SG12/top50",
          "chosen_threshold": 0.45,
          "reference_threshold": 0.45,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.7993483891359897,
          "train_miou_reference": 0.7993483891359897,
          "heldout_miou_chosen": 0.7980079201556065,
          "heldout_miou_reference": 0.7980079201556065
        },
        {
          "fold": 1,
          "chosen": "W/SG12/top50",
          "chosen_threshold": 0.45,
          "reference_threshold": 0.45,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.792573796601294,
          "train_miou_reference": 0.792573796601294,
          "heldout_miou_chosen": 0.8210694391882276,
          "heldout_miou_reference": 0.8210694391882276
        },
        {
          "fold": 2,
          "chosen": "W/SG12/top50",
          "chosen_threshold": 0.45,
          "reference_threshold": 0.45,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.8000770040354752,
          "train_miou_reference": 0.8000770040354752,
          "heldout_miou_chosen": 0.7957113805320305,
          "heldout_miou_reference": 0.7957113805320305
        },
        {
          "fold": 3,
          "chosen": "W/SG12/top50",
          "chosen_threshold": 0.45,
          "reference_threshold": 0.45,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.8011205136263397,
          "train_miou_reference": 0.8011205136263397,
          "heldout_miou_chosen": 0.7904002140640006,
          "heldout_miou_reference": 0.7904002140640006
        },
        {
          "fold": 4,
          "chosen": "W/SG12/top50",
          "chosen_threshold": 0.475,
          "reference_threshold": 0.475,
          "reason": "no eligible candidate",
          "train_miou_chosen": 0.8000199383633966,
          "train_miou_reference": 0.8000199383633966,
          "heldout_miou_chosen": 0.7811817777136335,
          "heldout_miou_reference": 0.7811817777136335
        }
      ],
      "selection_counts": {
        "W/SG12/top50": 5
      },
      "vote_winner": "W/SG12/top50",
      "vote_winner_votes": 5,
      "frozen": "W/SG12/top50",
      "freeze_reason": "reference won the fold vote",
      "oof_miou_selection": 0.796657782422708,
      "oof_miou_reference": 0.796657782422708,
      "oof_gain": 0.0,
      "full_threshold_frozen": 0.45,
      "full_threshold_reference": 0.45,
      "full_miou_frozen": 0.7985584168680424,
      "full_miou_reference": 0.7985584168680424,
      "paired_oof": {
        "mean": 0.0,
        "ci_low": 0.0,
        "ci_high": 0.0,
        "better": 0,
        "worse": 0,
        "ties": 490
      }
    }
  },
  "forced_cell_oof": {
    "W/REF": {
      "miou": 0.7872797008862745,
      "folds": [
        {
          "fold": 0,
          "threshold": 0.425,
          "heldout_miou": 0.7854325094473272
        },
        {
          "fold": 1,
          "threshold": 0.425,
          "heldout_miou": 0.8114630875761657
        },
        {
          "fold": 2,
          "threshold": 0.425,
          "heldout_miou": 0.7859289428172378
        },
        {
          "fold": 3,
          "threshold": 0.425,
          "heldout_miou": 0.7802224546432177
        },
        {
          "fold": 4,
          "threshold": 0.45,
          "heldout_miou": 0.7751596960962914
        }
      ],
      "mean_image_iou": 0.7882113942364494
    },
    "W/P1": {
      "miou": 0.7996523496064184,
      "folds": [
        {
          "fold": 0,
          "threshold": 0.45,
          "heldout_miou": 0.8043717755713968
        },
        {
          "fold": 1,
          "threshold": 0.45,
          "heldout_miou": 0.8236552709257694
        },
        {
          "fold": 2,
          "threshold": 0.45,
          "heldout_miou": 0.8023293971713426
        },
        {
          "fold": 3,
          "threshold": 0.45,
          "heldout_miou": 0.7905416055541602
        },
        {
          "fold": 4,
          "threshold": 0.475,
          "heldout_miou": 0.7818058154631513
        }
      ],
      "mean_image_iou": 0.8025622117538839
    },
    "W/SG11/trim20/rho0p80": {
      "miou": 0.798400027953512,
      "folds": [
        {
          "fold": 0,
          "threshold": 0.425,
          "heldout_miou": 0.7981035044997601
        },
        {
          "fold": 1,
          "threshold": 0.425,
          "heldout_miou": 0.8152177748924299
        },
        {
          "fold": 2,
          "threshold": 0.425,
          "heldout_miou": 0.7983786747748505
        },
        {
          "fold": 3,
          "threshold": 0.425,
          "heldout_miou": 0.7925278595866733
        },
        {
          "fold": 4,
          "threshold": 0.425,
          "heldout_miou": 0.7859481776989832
        }
      ],
      "mean_image_iou": 0.7974127767071819
    },
    "W/SG12/top50": {
      "miou": 0.796657782422708,
      "folds": [
        {
          "fold": 0,
          "threshold": 0.45,
          "heldout_miou": 0.7980079201556065
        },
        {
          "fold": 1,
          "threshold": 0.45,
          "heldout_miou": 0.8210694391882276
        },
        {
          "fold": 2,
          "threshold": 0.45,
          "heldout_miou": 0.7957113805320305
        },
        {
          "fold": 3,
          "threshold": 0.45,
          "heldout_miou": 0.7904002140640006
        },
        {
          "fold": 4,
          "threshold": 0.475,
          "heldout_miou": 0.7811817777136335
        }
      ],
      "mean_image_iou": 0.7992673340664536
    },
    "W/P1/SG15-A025": {
      "miou": 0.7718245000741086,
      "folds": [
        {
          "fold": 0,
          "threshold": 0.45,
          "heldout_miou": 0.770548487167731
        },
        {
          "fold": 1,
          "threshold": 0.45,
          "heldout_miou": 0.7908053036254655
        },
        {
          "fold": 2,
          "threshold": 0.45,
          "heldout_miou": 0.7713010354914531
        },
        {
          "fold": 3,
          "threshold": 0.45,
          "heldout_miou": 0.7639962008006468
        },
        {
          "fold": 4,
          "threshold": 0.475,
          "heldout_miou": 0.761303837877541
        }
      ],
      "mean_image_iou": 0.7700738597664795
    },
    "W/P1/SG15-A050": {
      "miou": 0.7857499327559736,
      "folds": [
        {
          "fold": 0,
          "threshold": 0.45,
          "heldout_miou": 0.7920482460722723
        },
        {
          "fold": 1,
          "threshold": 0.45,
          "heldout_miou": 0.8109930026007556
        },
        {
          "fold": 2,
          "threshold": 0.45,
          "heldout_miou": 0.7858779931200776
        },
        {
          "fold": 3,
          "threshold": 0.45,
          "heldout_miou": 0.7757580463727552
        },
        {
          "fold": 4,
          "threshold": 0.475,
          "heldout_miou": 0.7667776966151524
        }
      ],
      "mean_image_iou": 0.7868155203329706
    },
    "W/P1/SG15-A075": {
      "miou": 0.7812099734671583,
      "folds": [
        {
          "fold": 0,
          "threshold": 0.45,
          "heldout_miou": 0.7919661835959787
        },
        {
          "fold": 1,
          "threshold": 0.45,
          "heldout_miou": 0.8100060291393605
        },
        {
          "fold": 2,
          "threshold": 0.45,
          "heldout_miou": 0.7855821659439677
        },
        {
          "fold": 3,
          "threshold": 0.45,
          "heldout_miou": 0.765301937350346
        },
        {
          "fold": 4,
          "threshold": 0.475,
          "heldout_miou": 0.7595062379475748
        }
      ],
      "mean_image_iou": 0.7840086917606156
    },
    "W/P1/SG15-B": {
      "miou": 0.7964767722396566,
      "folds": [
        {
          "fold": 0,
          "threshold": 0.45,
          "heldout_miou": 0.8014661965557612
        },
        {
          "fold": 1,
          "threshold": 0.45,
          "heldout_miou": 0.8208284680709816
        },
        {
          "fold": 2,
          "threshold": 0.45,
          "heldout_miou": 0.79841424270959
        },
        {
          "fold": 3,
          "threshold": 0.45,
          "heldout_miou": 0.7878674671947291
        },
        {
          "fold": 4,
          "threshold": 0.475,
          "heldout_miou": 0.7776605460085441
        }
      ],
      "mean_image_iou": 0.7990040310096336
    },
    "W/SG11/trim20/rho0p80/SG15-A025": {
      "miou": 0.7748391814516831,
      "folds": [
        {
          "fold": 0,
          "threshold": 0.425,
          "heldout_miou": 0.7701186082564199
        },
        {
          "fold": 1,
          "threshold": 0.425,
          "heldout_miou": 0.7862844566371455
        },
        {
          "fold": 2,
          "threshold": 0.425,
          "heldout_miou": 0.7725032689597774
        },
        {
          "fold": 3,
          "threshold": 0.425,
          "heldout_miou": 0.769017000617599
        },
        {
          "fold": 4,
          "threshold": 0.425,
          "heldout_miou": 0.7723078371390137
        }
      ],
      "mean_image_iou": 0.7703387745120729
    },
    "W/SG11/trim20/rho0p80/SG15-A050": {
      "miou": 0.7882001450144269,
      "folds": [
        {
          "fold": 0,
          "threshold": 0.425,
          "heldout_miou": 0.7894544676086744
        },
        {
          "fold": 1,
          "threshold": 0.425,
          "heldout_miou": 0.8096532485142541
        },
        {
          "fold": 2,
          "threshold": 0.425,
          "heldout_miou": 0.7842642681942094
        },
        {
          "fold": 3,
          "threshold": 0.425,
          "heldout_miou": 0.7752210064874143
        },
        {
          "fold": 4,
          "threshold": 0.425,
          "heldout_miou": 0.7785411585352293
        }
      ],
      "mean_image_iou": 0.7863106949155261
    },
    "W/SG11/trim20/rho0p80/SG15-A075": {
      "miou": 0.7861714387303721,
      "folds": [
        {
          "fold": 0,
          "threshold": 0.425,
          "heldout_miou": 0.7952451800139967
        },
        {
          "fold": 1,
          "threshold": 0.425,
          "heldout_miou": 0.8057259740906215
        },
        {
          "fold": 2,
          "threshold": 0.425,
          "heldout_miou": 0.7850854240556945
        },
        {
          "fold": 3,
          "threshold": 0.425,
          "heldout_miou": 0.7729309427092296
        },
        {
          "fold": 4,
          "threshold": 0.425,
          "heldout_miou": 0.7711973962918204
        }
      ],
      "mean_image_iou": 0.7836385790866278
    },
    "W/SG11/trim20/rho0p80/SG15-B": {
      "miou": 0.7989335614439539,
      "folds": [
        {
          "fold": 0,
          "threshold": 0.425,
          "heldout_miou": 0.7987942723473144
        },
        {
          "fold": 1,
          "threshold": 0.425,
          "heldout_miou": 0.8148577916968929
        },
        {
          "fold": 2,
          "threshold": 0.425,
          "heldout_miou": 0.7980149520066463
        },
        {
          "fold": 3,
          "threshold": 0.425,
          "heldout_miou": 0.7940005575061885
        },
        {
          "fold": 4,
          "threshold": 0.425,
          "heldout_miou": 0.7870307761252298
        }
      ],
      "mean_image_iou": 0.7977207391849875
    },
    "W/SG12/top50/SG15-A025": {
      "miou": 0.7726462965246342,
      "folds": [
        {
          "fold": 0,
          "threshold": 0.45,
          "heldout_miou": 0.7688627781331541
        },
        {
          "fold": 1,
          "threshold": 0.45,
          "heldout_miou": 0.790746561344253
        },
        {
          "fold": 2,
          "threshold": 0.45,
          "heldout_miou": 0.7671501567445899
        },
        {
          "fold": 3,
          "threshold": 0.45,
          "heldout_miou": 0.768749329687046
        },
        {
          "fold": 4,
          "threshold": 0.475,
          "heldout_miou": 0.7669207688263
        }
      ],
      "mean_image_iou": 0.7704120014831269
    },
    "W/SG12/top50/SG15-A050": {
      "miou": 0.7836627615761088,
      "folds": [
        {
          "fold": 0,
          "threshold": 0.45,
          "heldout_miou": 0.78524944432863
        },
        {
          "fold": 1,
          "threshold": 0.45,
          "heldout_miou": 0.8106558365053909
        },
        {
          "fold": 2,
          "threshold": 0.45,
          "heldout_miou": 0.7828733803742652
        },
        {
          "fold": 3,
          "threshold": 0.45,
          "heldout_miou": 0.7742048409737505
        },
        {
          "fold": 4,
          "threshold": 0.475,
          "heldout_miou": 0.7667628647475857
        }
      ],
      "mean_image_iou": 0.7849273849177861
    },
    "W/SG12/top50/SG15-A075": {
      "miou": 0.7801673461827994,
      "folds": [
        {
          "fold": 0,
          "threshold": 0.45,
          "heldout_miou": 0.7915254119151754
        },
        {
          "fold": 1,
          "threshold": 0.45,
          "heldout_miou": 0.8076571073768983
        },
        {
          "fold": 2,
          "threshold": 0.45,
          "heldout_miou": 0.7794570627088004
        },
        {
          "fold": 3,
          "threshold": 0.45,
          "heldout_miou": 0.768449867742189
        },
        {
          "fold": 4,
          "threshold": 0.475,
          "heldout_miou": 0.7577389886991898
        }
      ],
      "mean_image_iou": 0.7833009370925786
    },
    "W/SG12/top50/SG15-B": {
      "miou": 0.7949044364709758,
      "folds": [
        {
          "fold": 0,
          "threshold": 0.45,
          "heldout_miou": 0.7977221468698811
        },
        {
          "fold": 1,
          "threshold": 0.45,
          "heldout_miou": 0.8186084222842567
        },
        {
          "fold": 2,
          "threshold": 0.45,
          "heldout_miou": 0.7930360055355876
        },
        {
          "fold": 3,
          "threshold": 0.45,
          "heldout_miou": 0.790201414142071
        },
        {
          "fold": 4,
          "threshold": 0.475,
          "heldout_miou": 0.7784827147670322
        }
      ],
      "mean_image_iou": 0.7972757805269621
    }
  },
  "forced_oof_comparisons": {
    "W/P1_SG15-A": {
      "W/P1/SG15-A025": {
        "candidate_miou": 0.7718245000741086,
        "reference_miou": 0.7996523496064184,
        "delta": -0.027827849532309767,
        "paired_mean_image_iou": {
          "mean": -0.03248835198740421,
          "ci_low": -0.03622155846129182,
          "ci_high": -0.028702163408208047,
          "better": 96,
          "worse": 394,
          "ties": 0
        }
      },
      "W/P1/SG15-A050": {
        "candidate_miou": 0.7857499327559736,
        "reference_miou": 0.7996523496064184,
        "delta": -0.013902416850444799,
        "paired_mean_image_iou": {
          "mean": -0.015746691420913058,
          "ci_low": -0.018498304799988183,
          "ci_high": -0.012966629415274404,
          "better": 140,
          "worse": 350,
          "ties": 0
        }
      },
      "W/P1/SG15-A075": {
        "candidate_miou": 0.7812099734671583,
        "reference_miou": 0.7996523496064184,
        "delta": -0.01844237613926014,
        "paired_mean_image_iou": {
          "mean": -0.018553519993268174,
          "ci_low": -0.023576513032364715,
          "ci_high": -0.013619867806969822,
          "better": 181,
          "worse": 309,
          "ties": 0
        }
      }
    },
    "W/P1_SG15-B": {
      "W/P1/SG15-B": {
        "candidate_miou": 0.7964767722396566,
        "reference_miou": 0.7996523496064184,
        "delta": -0.0031755773667617726,
        "paired_mean_image_iou": {
          "mean": -0.0035581807442501105,
          "ci_low": -0.00472319489097696,
          "ci_high": -0.0024006860863839976,
          "better": 181,
          "worse": 309,
          "ties": 0
        }
      }
    },
    "W/SG11/trim20/rho0p80_SG15-A": {
      "W/SG11/trim20/rho0p80/SG15-A025": {
        "candidate_miou": 0.7748391814516831,
        "reference_miou": 0.798400027953512,
        "delta": -0.02356084650182888,
        "paired_mean_image_iou": {
          "mean": -0.027074002195109144,
          "ci_low": -0.031412192464300534,
          "ci_high": -0.022533373412114695,
          "better": 117,
          "worse": 373,
          "ties": 0
        }
      },
      "W/SG11/trim20/rho0p80/SG15-A050": {
        "candidate_miou": 0.7882001450144269,
        "reference_miou": 0.798400027953512,
        "delta": -0.010199882939085025,
        "paired_mean_image_iou": {
          "mean": -0.011102081791655893,
          "ci_low": -0.014055921554092627,
          "ci_high": -0.00810237917492911,
          "better": 183,
          "worse": 307,
          "ties": 0
        }
      },
      "W/SG11/trim20/rho0p80/SG15-A075": {
        "candidate_miou": 0.7861714387303721,
        "reference_miou": 0.798400027953512,
        "delta": -0.012228589223139852,
        "paired_mean_image_iou": {
          "mean": -0.013774197620554129,
          "ci_low": -0.019415604094652636,
          "ci_high": -0.00823269409339893,
          "better": 207,
          "worse": 283,
          "ties": 0
        }
      }
    },
    "W/SG11/trim20/rho0p80_SG15-B": {
      "W/SG11/trim20/rho0p80/SG15-B": {
        "candidate_miou": 0.7989335614439539,
        "reference_miou": 0.798400027953512,
        "delta": 0.0005335334904419398,
        "paired_mean_image_iou": {
          "mean": 0.00030796247780549347,
          "ci_low": -0.0009950914915192685,
          "ci_high": 0.001644895788300929,
          "better": 239,
          "worse": 251,
          "ties": 0
        }
      }
    },
    "W/SG12/top50_SG15-A": {
      "W/SG12/top50/SG15-A025": {
        "candidate_miou": 0.7726462965246342,
        "reference_miou": 0.796657782422708,
        "delta": -0.02401148589807378,
        "paired_mean_image_iou": {
          "mean": -0.028855332583326485,
          "ci_low": -0.033028976406357324,
          "ci_high": -0.024659545402946553,
          "better": 106,
          "worse": 384,
          "ties": 0
        }
      },
      "W/SG12/top50/SG15-A050": {
        "candidate_miou": 0.7836627615761088,
        "reference_miou": 0.796657782422708,
        "delta": -0.012995020846599203,
        "paired_mean_image_iou": {
          "mean": -0.014339949148667598,
          "ci_low": -0.01710067638485819,
          "ci_high": -0.01156548691046266,
          "better": 153,
          "worse": 337,
          "ties": 0
        }
      },
      "W/SG12/top50/SG15-A075": {
        "candidate_miou": 0.7801673461827994,
        "reference_miou": 0.796657782422708,
        "delta": -0.016490436239908646,
        "paired_mean_image_iou": {
          "mean": -0.015966396973874936,
          "ci_low": -0.021068110901243532,
          "ci_high": -0.010972740186408666,
          "better": 198,
          "worse": 292,
          "ties": 0
        }
      }
    },
    "W/SG12/top50_SG15-B": {
      "W/SG12/top50/SG15-B": {
        "candidate_miou": 0.7949044364709758,
        "reference_miou": 0.796657782422708,
        "delta": -0.0017533459517322658,
        "paired_mean_image_iou": {
          "mean": -0.0019915535394915596,
          "ci_low": -0.003336572538636674,
          "ci_high": -0.0006507726962685763,
          "better": 206,
          "worse": 284,
          "ties": 0
        }
      }
    }
  },
  "screen_frozen_transfer": {
    "W/P1_SG15-A": {
      "reference": "W/P1",
      "frozen": "W/P1",
      "reference_threshold": 0.45,
      "frozen_threshold": 0.45,
      "reference_coco_miou": 0.6244708871408149,
      "frozen_coco_miou": 0.6244708871408149
    },
    "W/P1_SG15-B": {
      "reference": "W/P1",
      "frozen": "W/P1",
      "reference_threshold": 0.45,
      "frozen_threshold": 0.45,
      "reference_coco_miou": 0.6244708871408149,
      "frozen_coco_miou": 0.6244708871408149
    },
    "W/SG11/trim20/rho0p80_SG15-A": {
      "reference": "W/SG11/trim20/rho0p80",
      "frozen": "W/SG11/trim20/rho0p80",
      "reference_threshold": 0.425,
      "frozen_threshold": 0.425,
      "reference_coco_miou": 0.6219155223421355,
      "frozen_coco_miou": 0.6219155223421355
    },
    "W/SG11/trim20/rho0p80_SG15-B": {
      "reference": "W/SG11/trim20/rho0p80",
      "frozen": "W/SG11/trim20/rho0p80",
      "reference_threshold": 0.425,
      "frozen_threshold": 0.425,
      "reference_coco_miou": 0.6219155223421355,
      "frozen_coco_miou": 0.6219155223421355
    },
    "W/SG12/top50_SG15-A": {
      "reference": "W/SG12/top50",
      "frozen": "W/SG12/top50",
      "reference_threshold": 0.45,
      "frozen_threshold": 0.45,
      "reference_coco_miou": 0.6271735100277616,
      "frozen_coco_miou": 0.6271735100277616
    },
    "W/SG12/top50_SG15-B": {
      "reference": "W/SG12/top50",
      "frozen": "W/SG12/top50",
      "reference_threshold": 0.45,
      "frozen_threshold": 0.45,
      "reference_coco_miou": 0.6271735100277616,
      "frozen_coco_miou": 0.6271735100277616
    }
  }
}
```

## All class results

dataset,cell,reference,class,threshold,iou,delta
voc,W/REF,W/REF,aeroplane,0.425,0.8352635722287826,0.0
voc,W/REF,W/REF,bicycle,0.425,0.737438165800942,0.0
voc,W/REF,W/REF,bird,0.425,0.8403247874482437,0.0
voc,W/REF,W/REF,boat,0.425,0.8124661032715629,0.0
voc,W/REF,W/REF,bottle,0.425,0.8561283615303112,0.0
voc,W/REF,W/REF,bus,0.425,0.9089213701956407,0.0
voc,W/REF,W/REF,car,0.425,0.8254276616207066,0.0
voc,W/REF,W/REF,cat,0.425,0.8131546400743833,0.0
voc,W/REF,W/REF,chair,0.425,0.629114721949853,0.0
voc,W/REF,W/REF,cow,0.425,0.8426602356685133,0.0
voc,W/REF,W/REF,dining-table,0.425,0.45270798975063226,0.0
voc,W/REF,W/REF,dog,0.425,0.9028583590477207,0.0
voc,W/REF,W/REF,horse,0.425,0.8655564550590958,0.0
voc,W/REF,W/REF,motorbike,0.425,0.839833950438049,0.0
voc,W/REF,W/REF,person,0.425,0.7057082886035627,0.0
voc,W/REF,W/REF,potted-plant,0.425,0.7310806715606982,0.0
voc,W/REF,W/REF,sheep,0.425,0.8001454640174295,0.0
voc,W/REF,W/REF,sofa,0.425,0.9368351592460529,0.0
voc,W/REF,W/REF,train,0.425,0.6433302895856994,0.0
voc,W/REF,W/REF,tv,0.425,0.7932418189177365,0.0
coco,W/REF,W/REF,aeroplane,0.425,0.5639089672172332,0.0
coco,W/REF,W/REF,bicycle,0.425,0.5813415797451317,0.0
coco,W/REF,W/REF,bird,0.425,0.7128468945430074,0.0
coco,W/REF,W/REF,boat,0.425,0.5174657041725186,0.0
coco,W/REF,W/REF,bottle,0.425,0.45657259822166135,0.0
coco,W/REF,W/REF,bus,0.425,0.9200937035017466,0.0
coco,W/REF,W/REF,car,0.425,0.5682754030772628,0.0
coco,W/REF,W/REF,cat,0.425,0.8286793983910459,0.0
coco,W/REF,W/REF,chair,0.425,0.4190301468853303,0.0
coco,W/REF,W/REF,cow,0.425,0.8005908527741239,0.0
coco,W/REF,W/REF,dining table,0.425,0.3742098228693574,0.0
coco,W/REF,W/REF,dog,0.425,0.7450744893666833,0.0
coco,W/REF,W/REF,horse,0.425,0.6354861139057686,0.0
coco,W/REF,W/REF,motorbike,0.425,0.6175213013121482,0.0
coco,W/REF,W/REF,person,0.425,0.21896664030149351,0.0
coco,W/REF,W/REF,potted plant,0.425,0.6430209450112684,0.0
coco,W/REF,W/REF,sheep,0.425,0.8455591644890148,0.0
coco,W/REF,W/REF,sofa,0.425,0.5901932607758212,0.0
coco,W/REF,W/REF,train,0.425,0.6075123829233591,0.0
coco,W/REF,W/REF,tv,0.425,0.6969191997964193,0.0
voc,W/P1,W/REF,aeroplane,0.45,0.8667233064113781,0.03145973418259551
voc,W/P1,W/REF,bicycle,0.45,0.7479688100389947,0.010530644238052722
voc,W/P1,W/REF,bird,0.45,0.8393990307429229,-0.0009257567053208016
voc,W/P1,W/REF,boat,0.45,0.8364798244241098,0.024013721152546963
voc,W/P1,W/REF,bottle,0.45,0.8641614408977321,0.008033079367420815
voc,W/P1,W/REF,bus,0.45,0.9048342755779042,-0.004087094617736486
voc,W/P1,W/REF,car,0.45,0.825555626602769,0.00012796498206246731
voc,W/P1,W/REF,cat,0.45,0.8257994172400851,0.012644777165701782
voc,W/P1,W/REF,chair,0.45,0.7090314096326927,0.07991668768283977
voc,W/P1,W/REF,cow,0.45,0.8438618425543178,0.001201606885804507
voc,W/P1,W/REF,dining-table,0.45,0.44906475758614767,-0.003643232164484589
voc,W/P1,W/REF,dog,0.45,0.9021220885212011,-0.000736270526519589
voc,W/P1,W/REF,horse,0.45,0.8745240110314191,0.008967555972323238
voc,W/P1,W/REF,motorbike,0.45,0.8506338393185044,0.010799888880455466
voc,W/P1,W/REF,person,0.45,0.7336328856928452,0.02792459708928252
voc,W/P1,W/REF,potted-plant,0.45,0.7489042955027874,0.01782362394208914
voc,W/P1,W/REF,sheep,0.45,0.7993203646184205,-0.0008250993990089883
voc,W/P1,W/REF,sofa,0.45,0.9482479174015093,0.011412758155456393
voc,W/P1,W/REF,train,0.45,0.6625303839241307,0.019200094338431284
voc,W/P1,W/REF,tv,0.45,0.7788978034924409,-0.01434401542529562
coco,W/P1,W/REF,aeroplane,0.45,0.587178187123291,0.023269219906057792
coco,W/P1,W/REF,bicycle,0.45,0.5689240406859062,-0.01241753905922549
coco,W/P1,W/REF,bird,0.45,0.7223834216586578,0.00953652711565034
coco,W/P1,W/REF,boat,0.45,0.5171934129200428,-0.0002722912524757426
coco,W/P1,W/REF,bottle,0.45,0.46406995987944305,0.007497361657781698
coco,W/P1,W/REF,bus,0.45,0.9054070266712473,-0.01468667683049929
coco,W/P1,W/REF,car,0.45,0.5581137523767445,-0.010161650700518221
coco,W/P1,W/REF,cat,0.45,0.8463892629151284,0.01770986452408252
coco,W/P1,W/REF,chair,0.45,0.43568564859445374,0.016655501709123444
coco,W/P1,W/REF,cow,0.45,0.8143433950195997,0.01375254224547584
coco,W/P1,W/REF,dining table,0.45,0.3862348871920122,0.012025064322654822
coco,W/P1,W/REF,dog,0.45,0.7434133452977393,-0.0016611440689440204
coco,W/P1,W/REF,horse,0.45,0.6454537308929894,0.009967616987220818
coco,W/P1,W/REF,motorbike,0.45,0.6184382855637731,0.0009169842516248972
coco,W/P1,W/REF,person,0.45,0.23539629463971476,0.016429654338221245
coco,W/P1,W/REF,potted plant,0.45,0.6699416478955144,0.026920702884245973
coco,W/P1,W/REF,sheep,0.45,0.8627351702470436,0.0171760057580288
coco,W/P1,W/REF,sofa,0.45,0.6020553643144004,0.011862103538579194
coco,W/P1,W/REF,train,0.45,0.614498858788715,0.0069864758653559456
coco,W/P1,W/REF,tv,0.45,0.691562050139881,-0.005357149656538218
voc,W/SG11/trim20/rho0p80,W/REF,aeroplane,0.425,0.8464271651296567,0.011163592900874098
voc,W/SG11/trim20/rho0p80,W/REF,bicycle,0.425,0.7297935426619409,-0.007644623139001161
voc,W/SG11/trim20/rho0p80,W/REF,bird,0.425,0.8455293454533959,0.005204558005152182
voc,W/SG11/trim20/rho0p80,W/REF,boat,0.425,0.8452502193137245,0.03278411604216158
voc,W/SG11/trim20/rho0p80,W/REF,bottle,0.425,0.8664388294087437,0.010310467878432483
voc,W/SG11/trim20/rho0p80,W/REF,bus,0.425,0.9188366125574761,0.009915242361835386
voc,W/SG11/trim20/rho0p80,W/REF,car,0.425,0.826119225745161,0.0006915641244543691
voc,W/SG11/trim20/rho0p80,W/REF,cat,0.425,0.8276764835115531,0.014521843437169779
voc,W/SG11/trim20/rho0p80,W/REF,chair,0.425,0.6767276701797368,0.04761294822988382
voc,W/SG11/trim20/rho0p80,W/REF,cow,0.425,0.8484772420808906,0.005817006412377257
voc,W/SG11/trim20/rho0p80,W/REF,dining-table,0.425,0.46858883153663017,0.015880841785997912
voc,W/SG11/trim20/rho0p80,W/REF,dog,0.425,0.9012782994867968,-0.0015800595609238854
voc,W/SG11/trim20/rho0p80,W/REF,horse,0.425,0.8677548455394017,0.0021983904803059007
voc,W/SG11/trim20/rho0p80,W/REF,motorbike,0.425,0.8352628849213675,-0.004571065516681516
voc,W/SG11/trim20/rho0p80,W/REF,person,0.425,0.6971892634193377,-0.008519025184224982
voc,W/SG11/trim20/rho0p80,W/REF,potted-plant,0.425,0.7212579012695256,-0.009822770291172622
voc,W/SG11/trim20/rho0p80,W/REF,sheep,0.425,0.8409600522120914,0.04081458819466188
voc,W/SG11/trim20/rho0p80,W/REF,sofa,0.425,0.9309212897438567,-0.0059138695021961896
voc,W/SG11/trim20/rho0p80,W/REF,train,0.425,0.6795840740946458,0.03625378450894645
voc,W/SG11/trim20/rho0p80,W/REF,tv,0.425,0.7939267808043061,0.000684961886569635
coco,W/SG11/trim20/rho0p80,W/REF,aeroplane,0.425,0.5938088895748422,0.029899922357609077
coco,W/SG11/trim20/rho0p80,W/REF,bicycle,0.425,0.5970640900165662,0.015722510271434564
coco,W/SG11/trim20/rho0p80,W/REF,bird,0.425,0.7056429928181055,-0.007203901724901929
coco,W/SG11/trim20/rho0p80,W/REF,boat,0.425,0.5490289328595861,0.03156322868706751
coco,W/SG11/trim20/rho0p80,W/REF,bottle,0.425,0.4831149311523209,0.02654233293065955
coco,W/SG11/trim20/rho0p80,W/REF,bus,0.425,0.9242249786981986,0.004131275196452067
coco,W/SG11/trim20/rho0p80,W/REF,car,0.425,0.5465319265416768,-0.02174347653558595
coco,W/SG11/trim20/rho0p80,W/REF,cat,0.425,0.8377221168691091,0.00904271847806326
coco,W/SG11/trim20/rho0p80,W/REF,chair,0.425,0.4341028152434696,0.015072668358139307
coco,W/SG11/trim20/rho0p80,W/REF,cow,0.425,0.8124352985564612,0.011844445782337343
coco,W/SG11/trim20/rho0p80,W/REF,dining table,0.425,0.33358330756204163,-0.04062651530731576
coco,W/SG11/trim20/rho0p80,W/REF,dog,0.425,0.7435615415477532,-0.0015129478189300771
coco,W/SG11/trim20/rho0p80,W/REF,horse,0.425,0.6520243605775446,0.016538246671776058
coco,W/SG11/trim20/rho0p80,W/REF,motorbike,0.425,0.6293290066631625,0.011807705351014275
coco,W/SG11/trim20/rho0p80,W/REF,person,0.425,0.22128343391879743,0.002316793617303914
coco,W/SG11/trim20/rho0p80,W/REF,potted plant,0.425,0.6548142760133022,0.011793331002033836
coco,W/SG11/trim20/rho0p80,W/REF,sheep,0.425,0.8616753229243954,0.016116158435380612
coco,W/SG11/trim20/rho0p80,W/REF,sofa,0.425,0.570680239796403,-0.019513020979418205
coco,W/SG11/trim20/rho0p80,W/REF,train,0.425,0.6026238821184169,-0.004888500804942186
coco,W/SG11/trim20/rho0p80,W/REF,tv,0.425,0.68505810339056,-0.011861096405859306
voc,W/SG12/top50,W/REF,aeroplane,0.45,0.8551831673256742,0.019919595096891674
voc,W/SG12/top50,W/REF,bicycle,0.45,0.7452900929578082,0.007851927156866223
voc,W/SG12/top50,W/REF,bird,0.45,0.8564873864040521,0.016162598955808405
voc,W/SG12/top50,W/REF,boat,0.45,0.8349081845199188,0.022442081248355894
voc,W/SG12/top50,W/REF,bottle,0.45,0.8650743004251582,0.008945938894846961
voc,W/SG12/top50,W/REF,bus,0.45,0.9149153182349083,0.005993948039267671
voc,W/SG12/top50,W/REF,car,0.45,0.8331636144818277,0.007735952861121165
voc,W/SG12/top50,W/REF,cat,0.45,0.8088836400489084,-0.004271000025474869
voc,W/SG12/top50,W/REF,chair,0.45,0.6774630278879507,0.04834830593809769
voc,W/SG12/top50,W/REF,cow,0.45,0.8456211706998886,0.002960935031375289
voc,W/SG12/top50,W/REF,dining-table,0.45,0.4615386029282244,0.00883061317759215
voc,W/SG12/top50,W/REF,dog,0.45,0.9021113160917039,-0.0007470429560167968
voc,W/SG12/top50,W/REF,horse,0.45,0.8775036538322383,0.011947198773142431
voc,W/SG12/top50,W/REF,motorbike,0.45,0.8500637872967285,0.010229836858679509
voc,W/SG12/top50,W/REF,person,0.45,0.7225903577327976,0.016882069129234845
voc,W/SG12/top50,W/REF,potted-plant,0.45,0.7340156136998037,0.002934942139105501
voc,W/SG12/top50,W/REF,sheep,0.45,0.7844944353009128,-0.01565102871651669
voc,W/SG12/top50,W/REF,sofa,0.45,0.9477164299458083,0.010881270699755419
voc,W/SG12/top50,W/REF,train,0.45,0.669341712707643,0.0260114231219436
voc,W/SG12/top50,W/REF,tv,0.45,0.7848025248388913,-0.008439294078845139
coco,W/SG12/top50,W/REF,aeroplane,0.45,0.5900271553321144,0.026118188114881202
coco,W/SG12/top50,W/REF,bicycle,0.45,0.5803237423280837,-0.0010178374170479731
coco,W/SG12/top50,W/REF,bird,0.45,0.7159952205631942,0.0031483260201867758
coco,W/SG12/top50,W/REF,boat,0.45,0.530093329622414,0.012627625449895374
coco,W/SG12/top50,W/REF,bottle,0.45,0.4730029835566697,0.016430385335008346
coco,W/SG12/top50,W/REF,bus,0.45,0.9178582139706918,-0.0022354895310547906
coco,W/SG12/top50,W/REF,car,0.45,0.5629056930097877,-0.005369710067475109
coco,W/SG12/top50,W/REF,cat,0.45,0.8387175174664953,0.010038119075449381
coco,W/SG12/top50,W/REF,chair,0.45,0.42745203301870277,0.00842188613337247
coco,W/SG12/top50,W/REF,cow,0.45,0.8159134906457183,0.01532263787159438
coco,W/SG12/top50,W/REF,dining table,0.45,0.3807444032975091,0.006534580428151693
coco,W/SG12/top50,W/REF,dog,0.45,0.7460987487672033,0.0010242594005199779
coco,W/SG12/top50,W/REF,horse,0.45,0.6540135143737305,0.018527400467961863
coco,W/SG12/top50,W/REF,motorbike,0.45,0.6275318139701992,0.010010512658050974
coco,W/SG12/top50,W/REF,person,0.45,0.23774273358530068,0.018776093283807166
coco,W/SG12/top50,W/REF,potted plant,0.45,0.660547683027553,0.01752673801628457
coco,W/SG12/top50,W/REF,sheep,0.45,0.8677052584529141,0.022146093963899327
coco,W/SG12/top50,W/REF,sofa,0.45,0.5984718293318083,0.008278568555987076
coco,W/SG12/top50,W/REF,train,0.45,0.6181185621875782,0.01060617926421914
coco,W/SG12/top50,W/REF,tv,0.45,0.7002062740475652,0.0032870742511459383
voc,W/P1/SG15-A025,W/P1,aeroplane,0.45,0.8021987842935279,-0.0645245221178502
voc,W/P1/SG15-A025,W/P1,bicycle,0.45,0.7166272716573343,-0.03134153838166043
voc,W/P1/SG15-A025,W/P1,bird,0.45,0.7757883386657493,-0.06361069207717363
voc,W/P1/SG15-A025,W/P1,boat,0.45,0.7847712920130804,-0.05170853241102946
voc,W/P1/SG15-A025,W/P1,bottle,0.45,0.8288931502545911,-0.035268290643140965
voc,W/P1/SG15-A025,W/P1,bus,0.45,0.8609433190392695,-0.04389095653863473
voc,W/P1/SG15-A025,W/P1,car,0.45,0.7993225034347762,-0.026233123167992867
voc,W/P1/SG15-A025,W/P1,cat,0.45,0.8305305572035738,0.0047311399634887286
voc,W/P1/SG15-A025,W/P1,chair,0.45,0.6595769567694698,-0.04945445286322292
voc,W/P1/SG15-A025,W/P1,cow,0.45,0.8157959227095478,-0.028065919844770026
voc,W/P1/SG15-A025,W/P1,dining-table,0.45,0.42244840175180665,-0.02661635583434102
voc,W/P1/SG15-A025,W/P1,dog,0.45,0.8816765897431207,-0.02044549877808044
voc,W/P1/SG15-A025,W/P1,horse,0.45,0.8428211076510317,-0.03170290338038739
voc,W/P1/SG15-A025,W/P1,motorbike,0.45,0.8106688872041977,-0.03996495211430673
voc,W/P1/SG15-A025,W/P1,person,0.45,0.7458892566895036,0.012256370996658328
voc,W/P1/SG15-A025,W/P1,potted-plant,0.45,0.7470599610952484,-0.00184433440753895
voc,W/P1/SG15-A025,W/P1,sheep,0.45,0.7999939176096785,0.0006735529912580418
voc,W/P1/SG15-A025,W/P1,sofa,0.45,0.9244090658447269,-0.023838851556782337
voc,W/P1/SG15-A025,W/P1,train,0.45,0.6217783445325872,-0.04075203939154348
voc,W/P1/SG15-A025,W/P1,tv,0.45,0.7756223006165309,-0.0032755028759099414
coco,W/P1/SG15-A025,W/P1,aeroplane,0.45,0.5419900085588727,-0.04518817856441826
coco,W/P1/SG15-A025,W/P1,bicycle,0.45,0.5237939404293286,-0.0451301002565776
coco,W/P1/SG15-A025,W/P1,bird,0.45,0.6497015509911338,-0.07268187066752396
coco,W/P1/SG15-A025,W/P1,boat,0.45,0.4780456249714047,-0.03914778794863816
coco,W/P1/SG15-A025,W/P1,bottle,0.45,0.42849069319093036,-0.03557926668851269
coco,W/P1/SG15-A025,W/P1,bus,0.45,0.8628634624235266,-0.042543564247720655
coco,W/P1/SG15-A025,W/P1,car,0.45,0.5310309839319816,-0.027082768444762984
coco,W/P1/SG15-A025,W/P1,cat,0.45,0.7944719081602478,-0.051917354754880574
coco,W/P1/SG15-A025,W/P1,chair,0.45,0.41427458906152814,-0.021411059532925603
coco,W/P1/SG15-A025,W/P1,cow,0.45,0.7793470776418526,-0.03499631737774711
coco,W/P1/SG15-A025,W/P1,dining table,0.45,0.45528309918368265,0.06904821199167044
coco,W/P1/SG15-A025,W/P1,dog,0.45,0.6983056157404697,-0.045107729557269605
coco,W/P1/SG15-A025,W/P1,horse,0.45,0.5869504803997123,-0.05850325049327709
coco,W/P1/SG15-A025,W/P1,motorbike,0.45,0.58034873999829,-0.03808954556548316
coco,W/P1/SG15-A025,W/P1,person,0.45,0.246228464689915,0.010832170050200235
coco,W/P1/SG15-A025,W/P1,potted plant,0.45,0.6318962558292638,-0.03804539206625057
coco,W/P1/SG15-A025,W/P1,sheep,0.45,0.8053495451494141,-0.057385625097629456
coco,W/P1/SG15-A025,W/P1,sofa,0.45,0.5612018697710967,-0.04085349454330378
coco,W/P1/SG15-A025,W/P1,train,0.45,0.5795873037268202,-0.034911555061894806
coco,W/P1/SG15-A025,W/P1,tv,0.45,0.6527744548041866,-0.038787595335694425
voc,W/P1/SG15-A050,W/P1,aeroplane,0.45,0.8337585592545753,-0.032964747156802754
voc,W/P1/SG15-A050,W/P1,bicycle,0.45,0.7274642382789994,-0.020504571759995316
voc,W/P1/SG15-A050,W/P1,bird,0.45,0.8276020464256078,-0.011796984317315129
voc,W/P1/SG15-A050,W/P1,boat,0.45,0.8333849642579819,-0.003094860166127922
voc,W/P1/SG15-A050,W/P1,bottle,0.45,0.8430629224092511,-0.02109851848848099
voc,W/P1/SG15-A050,W/P1,bus,0.45,0.8888264739050916,-0.01600780167281257
voc,W/P1/SG15-A050,W/P1,car,0.45,0.8168615011014204,-0.008694125501348626
voc,W/P1/SG15-A050,W/P1,cat,0.45,0.8182469099880687,-0.007552507252016394
voc,W/P1/SG15-A050,W/P1,chair,0.45,0.6892788862147289,-0.019752523417963852
voc,W/P1/SG15-A050,W/P1,cow,0.45,0.8233093824942215,-0.020552460060096367
voc,W/P1/SG15-A050,W/P1,dining-table,0.45,0.43965780215161643,-0.009406955434531239
voc,W/P1/SG15-A050,W/P1,dog,0.45,0.88057684859396,-0.02154523992724111
voc,W/P1/SG15-A050,W/P1,horse,0.45,0.8605240546033293,-0.013999956428089821
voc,W/P1/SG15-A050,W/P1,motorbike,0.45,0.8397043129331075,-0.010929526385396904
voc,W/P1/SG15-A050,W/P1,person,0.45,0.7263788395368582,-0.007254046155987015
voc,W/P1/SG15-A050,W/P1,potted-plant,0.45,0.7330345427317606,-0.015869752771026757
voc,W/P1/SG15-A050,W/P1,sheep,0.45,0.7870588866483226,-0.012261477970097912
voc,W/P1/SG15-A050,W/P1,sofa,0.45,0.9397334881046998,-0.008514429296809456
voc,W/P1/SG15-A050,W/P1,train,0.45,0.6625595724831183,2.9188558987591762e-05
voc,W/P1/SG15-A050,W/P1,tv,0.45,0.7679014040667801,-0.010996399425660774
coco,W/P1/SG15-A050,W/P1,aeroplane,0.45,0.5863514408533435,-0.0008267462699474981
coco,W/P1/SG15-A050,W/P1,bicycle,0.45,0.5494751952338863,-0.01944884545201986
coco,W/P1/SG15-A050,W/P1,bird,0.45,0.6906116961223978,-0.031771725536259954
coco,W/P1/SG15-A050,W/P1,boat,0.45,0.5166069886071812,-0.0005864243128615998
coco,W/P1/SG15-A050,W/P1,bottle,0.45,0.4619350145040361,-0.002134945375406927
coco,W/P1/SG15-A050,W/P1,bus,0.45,0.8866516162853766,-0.018755410385870697
coco,W/P1/SG15-A050,W/P1,car,0.45,0.5501877039361949,-0.007926048440549671
coco,W/P1/SG15-A050,W/P1,cat,0.45,0.8155727611975995,-0.03081650171752892
coco,W/P1/SG15-A050,W/P1,chair,0.45,0.43515082205764577,-0.0005348265368079752
coco,W/P1/SG15-A050,W/P1,cow,0.45,0.7815757940125561,-0.03276760100704368
coco,W/P1/SG15-A050,W/P1,dining table,0.45,0.3710757069003719,-0.015159180291640317
coco,W/P1/SG15-A050,W/P1,dog,0.45,0.7216667564560374,-0.021746588841701886
coco,W/P1/SG15-A050,W/P1,horse,0.45,0.6312558345356013,-0.014197896357388107
coco,W/P1/SG15-A050,W/P1,motorbike,0.45,0.6068904569805844,-0.011547828583188702
coco,W/P1/SG15-A050,W/P1,person,0.45,0.22700044347203793,-0.008395851167676827
coco,W/P1/SG15-A050,W/P1,potted plant,0.45,0.6593611828797489,-0.010580465015765483
coco,W/P1/SG15-A050,W/P1,sheep,0.45,0.8260384155194952,-0.03669675472754841
coco,W/P1/SG15-A050,W/P1,sofa,0.45,0.5942440458582461,-0.007811318456154348
coco,W/P1/SG15-A050,W/P1,train,0.45,0.6280406952573995,0.013541836468684454
coco,W/P1/SG15-A050,W/P1,tv,0.45,0.6794081888956282,-0.012153861244252884
voc,W/P1/SG15-A075,W/P1,aeroplane,0.45,0.8288566929701185,-0.03786661344125952
voc,W/P1/SG15-A075,W/P1,bicycle,0.45,0.7216557876953025,-0.02631302234369226
voc,W/P1/SG15-A075,W/P1,bird,0.45,0.819869939715216,-0.019529091027706835
voc,W/P1/SG15-A075,W/P1,boat,0.45,0.8478216598060014,0.011341835381891596
voc,W/P1/SG15-A075,W/P1,bottle,0.45,0.8572374394673123,-0.006924001430419713
voc,W/P1/SG15-A075,W/P1,bus,0.45,0.9017062338423301,-0.0031280417355741275
voc,W/P1/SG15-A075,W/P1,car,0.45,0.8253796482589243,-0.00017597834384475153
voc,W/P1/SG15-A075,W/P1,cat,0.45,0.7810677090060231,-0.04473170823406203
voc,W/P1/SG15-A075,W/P1,chair,0.45,0.7217917251864522,0.01276031555375945
voc,W/P1/SG15-A075,W/P1,cow,0.45,0.7982239996776404,-0.04563784287667749
voc,W/P1/SG15-A075,W/P1,dining-table,0.45,0.4609168228882088,0.011852065302061121
voc,W/P1/SG15-A075,W/P1,dog,0.45,0.8661085261384003,-0.036013562382800846
voc,W/P1/SG15-A075,W/P1,horse,0.45,0.8640003621933667,-0.010523648838052346
voc,W/P1/SG15-A075,W/P1,motorbike,0.45,0.8407892298794856,-0.009844609439018881
voc,W/P1/SG15-A075,W/P1,person,0.45,0.6842320198655867,-0.049400865827258555
voc,W/P1/SG15-A075,W/P1,potted-plant,0.45,0.6924779734068286,-0.05642632209595877
voc,W/P1/SG15-A075,W/P1,sheep,0.45,0.7655989885533876,-0.03372137606503289
voc,W/P1/SG15-A075,W/P1,sofa,0.45,0.9437153212822025,-0.0045325961193067865
voc,W/P1/SG15-A075,W/P1,train,0.45,0.6867942410858051,0.02426385716167445
voc,W/P1/SG15-A075,W/P1,tv,0.45,0.7523326757308006,-0.026565127761640217
coco,W/P1/SG15-A075,W/P1,aeroplane,0.45,0.6071780276539546,0.019999840530663615
coco,W/P1/SG15-A075,W/P1,bicycle,0.45,0.5701602122015915,0.001236171515685336
coco,W/P1/SG15-A075,W/P1,bird,0.45,0.6968008198764646,-0.02558260178219318
coco,W/P1/SG15-A075,W/P1,boat,0.45,0.5413339315147624,0.02414051859471955
coco,W/P1/SG15-A075,W/P1,bottle,0.45,0.47265454782516203,0.00858458794571898
coco,W/P1/SG15-A075,W/P1,bus,0.45,0.9096201070469437,0.004213080375696454
coco,W/P1/SG15-A075,W/P1,car,0.45,0.5589162555064624,0.0008025031297178575
coco,W/P1/SG15-A075,W/P1,cat,0.45,0.8171968178753642,-0.029192445039764148
coco,W/P1/SG15-A075,W/P1,chair,0.45,0.4261562399399077,-0.009529408654546045
coco,W/P1/SG15-A075,W/P1,cow,0.45,0.779075598537499,-0.035267796482100766
coco,W/P1/SG15-A075,W/P1,dining table,0.45,0.3252801762390198,-0.06095471095299243
coco,W/P1/SG15-A075,W/P1,dog,0.45,0.7121104616568793,-0.03130288364085998
coco,W/P1/SG15-A075,W/P1,horse,0.45,0.6451055826280243,-0.000348148264965098
coco,W/P1/SG15-A075,W/P1,motorbike,0.45,0.623686231261724,0.00524794569795084
coco,W/P1/SG15-A075,W/P1,person,0.45,0.21222716412139497,-0.023169130518319786
coco,W/P1/SG15-A075,W/P1,potted plant,0.45,0.6678797545132142,-0.0020618933823001173
coco,W/P1/SG15-A075,W/P1,sheep,0.45,0.8085059429514264,-0.05422922729561719
coco,W/P1/SG15-A075,W/P1,sofa,0.45,0.6232523288648358,0.021196964550435404
coco,W/P1/SG15-A075,W/P1,train,0.45,0.6409740508240409,0.02647519203532589
coco,W/P1/SG15-A075,W/P1,tv,0.45,0.703278546862308,0.011716496722426917
voc,W/P1/SG15-B,W/P1,aeroplane,0.45,0.8592331203992047,-0.007490186012173328
voc,W/P1/SG15-B,W/P1,bicycle,0.45,0.7425922829229754,-0.005376527116019325
voc,W/P1/SG15-B,W/P1,bird,0.45,0.8369584530964201,-0.0024405776465027396
voc,W/P1/SG15-B,W/P1,boat,0.45,0.8380538578844982,0.0015740334603883133
voc,W/P1/SG15-B,W/P1,bottle,0.45,0.8546022628219,-0.009559178075832064
voc,W/P1/SG15-B,W/P1,bus,0.45,0.9020225927371723,-0.002811682840731855
voc,W/P1/SG15-B,W/P1,car,0.45,0.823887439894293,-0.001668186708476016
voc,W/P1/SG15-B,W/P1,cat,0.45,0.8224659587423879,-0.0033334584976971726
voc,W/P1/SG15-B,W/P1,chair,0.45,0.703953603401209,-0.005077806231483684
voc,W/P1/SG15-B,W/P1,cow,0.45,0.8342432190588368,-0.009618623495481038
voc,W/P1/SG15-B,W/P1,dining-table,0.45,0.4461914631728538,-0.00287329441329387
voc,W/P1/SG15-B,W/P1,dog,0.45,0.897970495116877,-0.004151593404324139
voc,W/P1/SG15-B,W/P1,horse,0.45,0.8737413487365626,-0.0007826622948564621
voc,W/P1/SG15-B,W/P1,motorbike,0.45,0.8519081610380292,0.0012743217195247958
voc,W/P1/SG15-B,W/P1,person,0.45,0.732623692990986,-0.001009192701859285
voc,W/P1/SG15-B,W/P1,potted-plant,0.45,0.7471256585276224,-0.0017786369751650044
voc,W/P1/SG15-B,W/P1,sheep,0.45,0.7959810384957532,-0.0033393261226672966
voc,W/P1/SG15-B,W/P1,sofa,0.45,0.946154918915189,-0.0020929984863202744
voc,W/P1/SG15-B,W/P1,train,0.45,0.665932078977162,0.0034016950530313395
voc,W/P1/SG15-B,W/P1,tv,0.45,0.7734152886759387,-0.005482514816502193
coco,W/P1/SG15-B,W/P1,aeroplane,0.45,0.5862325974688183,-0.0009455896544726672
coco,W/P1/SG15-B,W/P1,bicycle,0.45,0.5709672081542222,0.0020431674683160095
coco,W/P1/SG15-B,W/P1,bird,0.45,0.7131804166258842,-0.009203005032773603
coco,W/P1/SG15-B,W/P1,boat,0.45,0.518820776640252,0.0016273637202091074
coco,W/P1/SG15-B,W/P1,bottle,0.45,0.46430904522613065,0.0002390853466875953
coco,W/P1/SG15-B,W/P1,bus,0.45,0.9052291816040151,-0.00017784506723217408
coco,W/P1/SG15-B,W/P1,car,0.45,0.5568951227790451,-0.001218629597699472
coco,W/P1/SG15-B,W/P1,cat,0.45,0.8416497623731342,-0.004739500541994235
coco,W/P1/SG15-B,W/P1,chair,0.45,0.4375035797847017,0.0018179311902479789
coco,W/P1/SG15-B,W/P1,cow,0.45,0.8083305737833033,-0.006012821236296428
coco,W/P1/SG15-B,W/P1,dining table,0.45,0.3870130394082362,0.0007781522162240151
coco,W/P1/SG15-B,W/P1,dog,0.45,0.7396945757745117,-0.003718769523227583
coco,W/P1/SG15-B,W/P1,horse,0.45,0.6422176946348089,-0.0032360362581804747
coco,W/P1/SG15-B,W/P1,motorbike,0.45,0.6161935659186908,-0.002244719645082327
coco,W/P1/SG15-B,W/P1,person,0.45,0.23244439142815224,-0.0029519032115625232
coco,W/P1/SG15-B,W/P1,potted plant,0.45,0.6711566784490146,0.0012150305535002515
coco,W/P1/SG15-B,W/P1,sheep,0.45,0.8555957008004531,-0.007139469446590496
coco,W/P1/SG15-B,W/P1,sofa,0.45,0.6014247786793879,-0.0006305856350125039
coco,W/P1/SG15-B,W/P1,train,0.45,0.6200774660282875,0.005578607239572486
coco,W/P1/SG15-B,W/P1,tv,0.45,0.6892277450430152,-0.0023343050968658297
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,aeroplane,0.425,0.7863044200838386,-0.06012274504581805
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,bicycle,0.425,0.6921771876823674,-0.037616354979573496
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,bird,0.425,0.7970118378986792,-0.04851750755471662
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,boat,0.425,0.7981891036407256,-0.047061115672998866
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,bottle,0.425,0.8403611712875205,-0.0260776581212232
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,bus,0.425,0.8857890960987344,-0.03304751645874171
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,car,0.425,0.7988005660321765,-0.027318659712984417
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,cat,0.425,0.8365482011664668,0.00887171765491368
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,chair,0.425,0.6388153933089797,-0.037912276870757045
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,cow,0.425,0.8358702534096301,-0.012606988671260533
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,dining-table,0.425,0.4263892577250845,-0.042199573811545654
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,dog,0.425,0.8831531351330395,-0.018125164353757328
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,horse,0.425,0.8319310615475654,-0.03582378399183639
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,motorbike,0.425,0.7869664370781599,-0.048296447843207524
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,person,0.425,0.7331730683343437,0.03598380491500597
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,potted-plant,0.425,0.7375353252831138,0.016277424013588226
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,sheep,0.425,0.8482179829137335,0.007257930701642157
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,sofa,0.425,0.9055120909988922,-0.0254091987449645
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,train,0.425,0.6301104880263775,-0.04947358606826835
voc,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,tv,0.425,0.8039275513842333,0.01000077057992721
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,aeroplane,0.425,0.5530635625200592,-0.040745327054783065
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,bicycle,0.425,0.5453781099466743,-0.05168598006989189
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,bird,0.425,0.6577194347918758,-0.04792355802622972
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,boat,0.425,0.5021228840050563,-0.04690604885452976
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,bottle,0.425,0.44807116950163656,-0.035043761650684346
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,bus,0.425,0.8851946334847439,-0.03903034521345472
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,car,0.425,0.5277565130527115,-0.018775413488965276
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,cat,0.425,0.8034717194379667,-0.03425039743114244
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,chair,0.425,0.39999977364375827,-0.03410304159971134
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,cow,0.425,0.7889570071837793,-0.02347829137268198
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,dining table,0.425,0.38724340372195165,0.05366009615991002
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,dog,0.425,0.7036780414058699,-0.039883500141883355
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,horse,0.425,0.5976640428703618,-0.05436031770718286
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,motorbike,0.425,0.5811249725697353,-0.04820403409342722
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,person,0.425,0.23482910482871658,0.01354567090991915
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,potted plant,0.425,0.6277117629189252,-0.027102513094377056
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,sheep,0.425,0.8108255703077926,-0.05084975261660285
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,sofa,0.425,0.534795771455167,-0.03588446834123604
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,train,0.425,0.5750419272447542,-0.027581954873662662
coco,W/SG11/trim20/rho0p80/SG15-A025,W/SG11/trim20/rho0p80,tv,0.425,0.670610391143315,-0.014447712247244948
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,aeroplane,0.425,0.8292597443453132,-0.017167420784343412
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,bicycle,0.425,0.72790506429526,-0.0018884783666808236
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,bird,0.425,0.8397790905648644,-0.005750254888531425
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,boat,0.425,0.8487203840192798,0.0034701647055553897
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,bottle,0.425,0.8413871555949612,-0.025051673813782482
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,bus,0.425,0.9004629947871351,-0.018373617770340966
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,car,0.425,0.821453464696825,-0.004665761048335937
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,cat,0.425,0.8204202467787577,-0.007256236732795407
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,chair,0.425,0.6653251952116114,-0.011402474968125409
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,cow,0.425,0.830971304730551,-0.017505937350339562
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,dining-table,0.425,0.45859418911060446,-0.009994642426025713
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,dog,0.425,0.8816635477257767,-0.01961475176102012
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,horse,0.425,0.8607475689546477,-0.007007276584754085
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,motorbike,0.425,0.8295361045905585,-0.005726780330808978
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,person,0.425,0.683246889923681,-0.013942373495656746
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,potted-plant,0.425,0.7076597729402935,-0.013598128329232129
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,sheep,0.425,0.8234700849235782,-0.017489967288513153
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,sofa,0.425,0.924721892951582,-0.0061993967922746585
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,train,0.425,0.6838183268270879,0.004234252732442045
voc,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,tv,0.425,0.7848598773161687,-0.009066903488137434
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,aeroplane,0.425,0.5905133500887162,-0.0032955394861260423
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,bicycle,0.425,0.593200582414323,-0.003863507602243188
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,bird,0.425,0.6757583838991245,-0.029884608918981037
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,boat,0.425,0.5448203233042536,-0.004208609555332532
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,bottle,0.425,0.4836499390407188,0.000535007888397887
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,bus,0.425,0.9115201558823314,-0.012704822815867267
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,car,0.425,0.5372259222494479,-0.009306004292228942
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,cat,0.425,0.8140084583139673,-0.023713658555141848
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,chair,0.425,0.42583763146164955,-0.008265183781820062
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,cow,0.425,0.7900135070945417,-0.022421791461919582
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,dining table,0.425,0.32262076963090386,-0.010962537931137772
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,dog,0.425,0.7246437177455274,-0.01891782380222584
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,horse,0.425,0.6392211079226006,-0.012803252654944086
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,motorbike,0.425,0.6211511497691258,-0.008177856894036717
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,person,0.425,0.2127035776008405,-0.008579856317956935
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,potted plant,0.425,0.6451816301320028,-0.009632645881299418
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,sheep,0.425,0.8275149553948875,-0.03416036752950791
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,sofa,0.425,0.5624903371018137,-0.008189902694589302
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,train,0.425,0.6103374833132701,0.0077136011948532035
coco,W/SG11/trim20/rho0p80/SG15-A050,W/SG11/trim20/rho0p80,tv,0.425,0.671080473384371,-0.013977630006188901
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,aeroplane,0.425,0.8284092178250996,-0.01801794730455708
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,bicycle,0.425,0.7283857225184742,-0.0014078201434666315
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,bird,0.425,0.828005087757362,-0.01752425769603383
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,boat,0.425,0.848366611155082,0.003116391841357591
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,bottle,0.425,0.8729522764896459,0.006513447080902179
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,bus,0.425,0.9061478839807037,-0.01268872857677239
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,car,0.425,0.838082266698001,0.011963040952840065
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,cat,0.425,0.7825274412757893,-0.04514904223576377
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,chair,0.425,0.6943950833308778,0.017667413151141065
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,cow,0.425,0.8096938693272943,-0.038783372753596335
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,dining-table,0.425,0.4948173952382104,0.02622856370158022
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,dog,0.425,0.8720061724345546,-0.029272127052242247
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,horse,0.425,0.8778372855948204,0.010082440055418695
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,motorbike,0.425,0.8456525579925117,0.010389673071144245
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,person,0.425,0.6257014076169695,-0.07148785580236827
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,potted-plant,0.425,0.6575239045643695,-0.06373399670515612
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,sheep,0.425,0.7958140972571193,-0.04514595495497209
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,sofa,0.425,0.9398942420337908,0.00897295228993411
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,train,0.425,0.71215266165501,0.03256858756036418
voc,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,tv,0.425,0.7650635898617553,-0.028863190942550854
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,aeroplane,0.425,0.6220427337877645,0.0282338442129223
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,bicycle,0.425,0.6057687392813267,0.008704649264760445
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,bird,0.425,0.6651489686783805,-0.04049402413972503
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,boat,0.425,0.5709880776101037,0.021959144750517634
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,bottle,0.425,0.488012865685279,0.004897934532958115
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,bus,0.425,0.9071892631288299,-0.01703571556936878
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,car,0.425,0.5438667968800022,-0.002665129661674648
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,cat,0.425,0.8023127625299578,-0.03540935433915138
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,chair,0.425,0.42742434535417406,-0.006678469889295546
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,cow,0.425,0.7846194705704158,-0.027815827986045427
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,dining table,0.425,0.2710410415007317,-0.06254226606130991
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,dog,0.425,0.7131803173660387,-0.030381224181714517
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,horse,0.425,0.6545293635290902,0.002505002951545543
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,motorbike,0.425,0.6407060342698607,0.011377027606698231
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,person,0.425,0.19497038781114684,-0.02631304610765059
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,potted plant,0.425,0.657832358736391,0.0030180827230887886
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,sheep,0.425,0.8134685814014868,-0.0482067415229086
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,sofa,0.425,0.5939237180847402,0.02324347828833717
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,train,0.425,0.6260879587519727,0.023464076633555764
coco,W/SG11/trim20/rho0p80/SG15-A075,W/SG11/trim20/rho0p80,tv,0.425,0.6848452022604065,-0.00021290113015348666
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,aeroplane,0.425,0.8451774009684329,-0.0012497641612237986
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,bicycle,0.425,0.7305961934127851,0.0008026507508442915
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,bird,0.425,0.8482237573466025,0.0026944118932066274
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,boat,0.425,0.8480013663226461,0.0027511470089216505
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,bottle,0.425,0.8677857994645398,0.0013469700557960929
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,bus,0.425,0.916137300391444,-0.0026993121660320307
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,car,0.425,0.8295060955305028,0.0033868697853418617
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,cat,0.425,0.8271994275600458,-0.0004770559515072659
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,chair,0.425,0.679630844102227,0.0029031739224901765
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,cow,0.425,0.8453082907308335,-0.0031689513500571254
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,dining-table,0.425,0.467112916112994,-0.001475915423636176
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,dog,0.425,0.9007002107381836,-0.0005780887486132036
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,horse,0.425,0.8719908977025893,0.004236052163187565
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,motorbike,0.425,0.8362473392521607,0.0009844543307931941
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,person,0.425,0.6955072559476676,-0.0016820074716701328
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,potted-plant,0.425,0.7226856007316447,0.0014276994621190697
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,sheep,0.425,0.8366714515405214,-0.004288600671569998
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,sofa,0.425,0.9328842530695546,0.0019629633256978973
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,train,0.425,0.6831095447305271,0.003525470635881267
voc,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,tv,0.425,0.7941952832231749,0.0002685024188687768
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,aeroplane,0.425,0.5957987833081643,0.0019898937333220346
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,bicycle,0.425,0.6027989843129851,0.005734894296418824
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,bird,0.425,0.7013687266694317,-0.0042742661486737665
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,boat,0.425,0.5520345127008461,0.003005579841260042
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,bottle,0.425,0.48338436482357866,0.0002694336712577572
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,bus,0.425,0.9231791475528721,-0.0010458311453265257
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,car,0.425,0.546005667846747,-0.0005262586949298376
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,cat,0.425,0.8360119563941949,-0.0017101604749142352
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,chair,0.425,0.43103784207145296,-0.0030649731720166495
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,cow,0.425,0.813643154891259,0.0012078563347978077
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,dining table,0.425,0.32759893559111375,-0.005984371970927882
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,dog,0.425,0.7422056740770172,-0.0013558674707360163
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,horse,0.425,0.6518964308532433,-0.00012792972430131222
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,motorbike,0.425,0.6281520404023102,-0.0011769662608522857
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,person,0.425,0.21843432044775155,-0.002849113471045883
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,potted plant,0.425,0.6597182573907833,0.004903981377481048
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,sheep,0.425,0.8583080094542482,-0.003367313470147182
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,sofa,0.425,0.5725299072934508,0.0018496674970477356
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,train,0.425,0.6077923492526209,0.005168467134204047
coco,W/SG11/trim20/rho0p80/SG15-B,W/SG11/trim20/rho0p80,tv,0.425,0.6885528048073382,0.003494701416778212
voc,W/SG12/top50/SG15-A025,W/SG12/top50,aeroplane,0.45,0.7866702620281331,-0.06851290529754117
voc,W/SG12/top50/SG15-A025,W/SG12/top50,bicycle,0.45,0.6983345808444105,-0.04695551211339777
voc,W/SG12/top50/SG15-A025,W/SG12/top50,bird,0.45,0.7914576415388728,-0.06502974486517932
voc,W/SG12/top50/SG15-A025,W/SG12/top50,boat,0.45,0.7867782392947695,-0.04812994522514924
voc,W/SG12/top50/SG15-A025,W/SG12/top50,bottle,0.45,0.8322963641328212,-0.03277793629233705
voc,W/SG12/top50/SG15-A025,W/SG12/top50,bus,0.45,0.8752342397161574,-0.03968107851875091
voc,W/SG12/top50/SG15-A025,W/SG12/top50,car,0.45,0.8114771740169702,-0.02168644046485757
voc,W/SG12/top50/SG15-A025,W/SG12/top50,cat,0.45,0.8278232463203389,0.01893960627143043
voc,W/SG12/top50/SG15-A025,W/SG12/top50,chair,0.45,0.6454273898978916,-0.03203563799005904
voc,W/SG12/top50/SG15-A025,W/SG12/top50,cow,0.45,0.8318304437703451,-0.013790726929543529
voc,W/SG12/top50/SG15-A025,W/SG12/top50,dining-table,0.45,0.4329556657933075,-0.028582937134916886
voc,W/SG12/top50/SG15-A025,W/SG12/top50,dog,0.45,0.8786798986349753,-0.02343141745672861
voc,W/SG12/top50/SG15-A025,W/SG12/top50,horse,0.45,0.8467193466900336,-0.030784307142204703
voc,W/SG12/top50/SG15-A025,W/SG12/top50,motorbike,0.45,0.8082622097783704,-0.04180157751835811
voc,W/SG12/top50/SG15-A025,W/SG12/top50,person,0.45,0.7615804700208434,0.03899011228804583
voc,W/SG12/top50/SG15-A025,W/SG12/top50,potted-plant,0.45,0.7403036875475733,0.006288073847769526
voc,W/SG12/top50/SG15-A025,W/SG12/top50,sheep,0.45,0.8035553724181831,0.019060937117270305
voc,W/SG12/top50/SG15-A025,W/SG12/top50,sofa,0.45,0.9262870017429256,-0.02142942820288274
voc,W/SG12/top50/SG15-A025,W/SG12/top50,train,0.45,0.6247018580424474,-0.0446398546651956
voc,W/SG12/top50/SG15-A025,W/SG12/top50,tv,0.45,0.7765856512234423,-0.008216873615449094
coco,W/SG12/top50/SG15-A025,W/SG12/top50,aeroplane,0.45,0.540665983201878,-0.049361172130236386
coco,W/SG12/top50/SG15-A025,W/SG12/top50,bicycle,0.45,0.5281987268709966,-0.05212501545708714
coco,W/SG12/top50/SG15-A025,W/SG12/top50,bird,0.45,0.6503707725662473,-0.06562444799694689
coco,W/SG12/top50/SG15-A025,W/SG12/top50,boat,0.45,0.4831300520969301,-0.04696327752548385
coco,W/SG12/top50/SG15-A025,W/SG12/top50,bottle,0.45,0.43446969450581696,-0.03853328905085274
coco,W/SG12/top50/SG15-A025,W/SG12/top50,bus,0.45,0.8757616639200707,-0.04209655005062107
coco,W/SG12/top50/SG15-A025,W/SG12/top50,car,0.45,0.5306548430455369,-0.03225084996425076
coco,W/SG12/top50/SG15-A025,W/SG12/top50,cat,0.45,0.7910469084765082,-0.047670608989987096
coco,W/SG12/top50/SG15-A025,W/SG12/top50,chair,0.45,0.4095329753260106,-0.017919057692692197
coco,W/SG12/top50/SG15-A025,W/SG12/top50,cow,0.45,0.78381741356086,-0.03209607708485829
coco,W/SG12/top50/SG15-A025,W/SG12/top50,dining table,0.45,0.44294763966721573,0.06220323636970665
coco,W/SG12/top50/SG15-A025,W/SG12/top50,dog,0.45,0.7009095845737854,-0.0451891641934179
coco,W/SG12/top50/SG15-A025,W/SG12/top50,horse,0.45,0.6019205358846266,-0.05209297848910388
coco,W/SG12/top50/SG15-A025,W/SG12/top50,motorbike,0.45,0.5794469901441128,-0.048084823826086365
coco,W/SG12/top50/SG15-A025,W/SG12/top50,person,0.45,0.24928787990247595,0.011545146317175264
coco,W/SG12/top50/SG15-A025,W/SG12/top50,potted plant,0.45,0.6250346857132192,-0.03551299731433377
coco,W/SG12/top50/SG15-A025,W/SG12/top50,sheep,0.45,0.8144790128608963,-0.05322624559201783
coco,W/SG12/top50/SG15-A025,W/SG12/top50,sofa,0.45,0.5580596086299021,-0.0404122207019062
coco,W/SG12/top50/SG15-A025,W/SG12/top50,train,0.45,0.581206202442996,-0.03691235974458218
coco,W/SG12/top50/SG15-A025,W/SG12/top50,tv,0.45,0.6708392386990294,-0.029367035348535797
voc,W/SG12/top50/SG15-A050,W/SG12/top50,aeroplane,0.45,0.827011464457417,-0.02817170286825721
voc,W/SG12/top50/SG15-A050,W/SG12/top50,bicycle,0.45,0.7381632341063604,-0.007126858851447815
voc,W/SG12/top50/SG15-A050,W/SG12/top50,bird,0.45,0.843464363948645,-0.013023022455407096
voc,W/SG12/top50/SG15-A050,W/SG12/top50,boat,0.45,0.8247442383621093,-0.010163946157809467
voc,W/SG12/top50/SG15-A050,W/SG12/top50,bottle,0.45,0.8364665690321217,-0.028607731393036517
voc,W/SG12/top50/SG15-A050,W/SG12/top50,bus,0.45,0.8971770420718918,-0.017738276163016597
voc,W/SG12/top50/SG15-A050,W/SG12/top50,car,0.45,0.8299918086229621,-0.003171805858865673
voc,W/SG12/top50/SG15-A050,W/SG12/top50,cat,0.45,0.7978892663353048,-0.010994373713603678
voc,W/SG12/top50/SG15-A050,W/SG12/top50,chair,0.45,0.664110152650704,-0.013352875237246598
voc,W/SG12/top50/SG15-A050,W/SG12/top50,cow,0.45,0.820235609461377,-0.025385561238511656
voc,W/SG12/top50/SG15-A050,W/SG12/top50,dining-table,0.45,0.44943774515875035,-0.01210085776947406
voc,W/SG12/top50/SG15-A050,W/SG12/top50,dog,0.45,0.8856227817026345,-0.016488534389069387
voc,W/SG12/top50/SG15-A050,W/SG12/top50,horse,0.45,0.8708063731007586,-0.006697280731479682
voc,W/SG12/top50/SG15-A050,W/SG12/top50,motorbike,0.45,0.8415852633486929,-0.00847852394803561
voc,W/SG12/top50/SG15-A050,W/SG12/top50,person,0.45,0.7206983032190504,-0.0018920545137471878
voc,W/SG12/top50/SG15-A050,W/SG12/top50,potted-plant,0.45,0.7224763168597912,-0.011539296840012536
voc,W/SG12/top50/SG15-A050,W/SG12/top50,sheep,0.45,0.7771144358582102,-0.007379999442702623
voc,W/SG12/top50/SG15-A050,W/SG12/top50,sofa,0.45,0.9409653463555273,-0.006751083590280982
voc,W/SG12/top50/SG15-A050,W/SG12/top50,train,0.45,0.6650719215624953,-0.004269791145147694
voc,W/SG12/top50/SG15-A050,W/SG12/top50,tv,0.45,0.7724055685101652,-0.012396956328726172
coco,W/SG12/top50/SG15-A050,W/SG12/top50,aeroplane,0.45,0.5864581474126416,-0.0035690079194727886
coco,W/SG12/top50/SG15-A050,W/SG12/top50,bicycle,0.45,0.577744089522052,-0.0025796528060316737
coco,W/SG12/top50/SG15-A050,W/SG12/top50,bird,0.45,0.6891293987040952,-0.026865821859099026
coco,W/SG12/top50/SG15-A050,W/SG12/top50,boat,0.45,0.5322287010200809,0.002135371397666952
coco,W/SG12/top50/SG15-A050,W/SG12/top50,bottle,0.45,0.47486816806031285,0.001865184503643147
coco,W/SG12/top50/SG15-A050,W/SG12/top50,bus,0.45,0.900427752992165,-0.01743046097852674
coco,W/SG12/top50/SG15-A050,W/SG12/top50,car,0.45,0.5591371011216805,-0.0037685918881071867
coco,W/SG12/top50/SG15-A050,W/SG12/top50,cat,0.45,0.8122378463321146,-0.026479671134380656
coco,W/SG12/top50/SG15-A050,W/SG12/top50,chair,0.45,0.4016555470955584,-0.025796485923144374
coco,W/SG12/top50/SG15-A050,W/SG12/top50,cow,0.45,0.7872311992866626,-0.028682291359055645
coco,W/SG12/top50/SG15-A050,W/SG12/top50,dining table,0.45,0.36109558968223127,-0.019648813615277816
coco,W/SG12/top50/SG15-A050,W/SG12/top50,dog,0.45,0.7241562110667858,-0.02194253770041743
coco,W/SG12/top50/SG15-A050,W/SG12/top50,horse,0.45,0.6443458738901102,-0.009667640483620232
coco,W/SG12/top50/SG15-A050,W/SG12/top50,motorbike,0.45,0.615030810929068,-0.01250100304113122
coco,W/SG12/top50/SG15-A050,W/SG12/top50,person,0.45,0.23251582391609696,-0.005226909669203722
coco,W/SG12/top50/SG15-A050,W/SG12/top50,potted plant,0.45,0.6564223598168,-0.004125323210752985
coco,W/SG12/top50/SG15-A050,W/SG12/top50,sheep,0.45,0.8340915314041308,-0.03361372704878329
coco,W/SG12/top50/SG15-A050,W/SG12/top50,sofa,0.45,0.5996755934250241,0.0012037640932157645
coco,W/SG12/top50/SG15-A050,W/SG12/top50,train,0.45,0.6260222147399618,0.007903652552383567
coco,W/SG12/top50/SG15-A050,W/SG12/top50,tv,0.45,0.6975216576927289,-0.0026846163548363
voc,W/SG12/top50/SG15-A075,W/SG12/top50,aeroplane,0.45,0.8305467197704774,-0.024636447555196783
voc,W/SG12/top50/SG15-A075,W/SG12/top50,bicycle,0.45,0.7417500084152447,-0.003540084542563493
voc,W/SG12/top50/SG15-A075,W/SG12/top50,bird,0.45,0.8440670126562152,-0.012420373747836888
voc,W/SG12/top50/SG15-A075,W/SG12/top50,boat,0.45,0.8487433465242433,0.013835162004324553
voc,W/SG12/top50/SG15-A075,W/SG12/top50,bottle,0.45,0.8580841652940715,-0.0069901351310867055
voc,W/SG12/top50/SG15-A075,W/SG12/top50,bus,0.45,0.9093132766460948,-0.0056020415888135
voc,W/SG12/top50/SG15-A075,W/SG12/top50,car,0.45,0.8356120360459716,0.002448421564143821
voc,W/SG12/top50/SG15-A075,W/SG12/top50,cat,0.45,0.7548648650996033,-0.05401877494930518
voc,W/SG12/top50/SG15-A075,W/SG12/top50,chair,0.45,0.7001140454142545,0.02265101752630383
voc,W/SG12/top50/SG15-A075,W/SG12/top50,cow,0.45,0.7914861614740116,-0.054135009225876995
voc,W/SG12/top50/SG15-A075,W/SG12/top50,dining-table,0.45,0.48231404497238706,0.02077544204416265
voc,W/SG12/top50/SG15-A075,W/SG12/top50,dog,0.45,0.8720424477740624,-0.03006886831764155
voc,W/SG12/top50/SG15-A075,W/SG12/top50,horse,0.45,0.8728388073391553,-0.004664846493082964
voc,W/SG12/top50/SG15-A075,W/SG12/top50,motorbike,0.45,0.8520564549549601,0.001992667658231584
voc,W/SG12/top50/SG15-A075,W/SG12/top50,person,0.45,0.652182854484414,-0.07040750324838352
voc,W/SG12/top50/SG15-A075,W/SG12/top50,potted-plant,0.45,0.6708638751926187,-0.06315173850718503
voc,W/SG12/top50/SG15-A075,W/SG12/top50,sheep,0.45,0.7350767233579734,-0.049417711942939424
voc,W/SG12/top50/SG15-A075,W/SG12/top50,sofa,0.45,0.9411434109151464,-0.006573019030661875
voc,W/SG12/top50/SG15-A075,W/SG12/top50,train,0.45,0.6939464965746669,0.024604783867023916
voc,W/SG12/top50/SG15-A075,W/SG12/top50,tv,0.45,0.7566792497432905,-0.028123275095600864
coco,W/SG12/top50/SG15-A075,W/SG12/top50,aeroplane,0.45,0.6186501080224509,0.028622952690336545
coco,W/SG12/top50/SG15-A075,W/SG12/top50,bicycle,0.45,0.5858201976329762,0.005496455304892511
coco,W/SG12/top50/SG15-A075,W/SG12/top50,bird,0.45,0.6959732861250199,-0.02002193443817435
coco,W/SG12/top50/SG15-A075,W/SG12/top50,boat,0.45,0.5525737873684421,0.022480457746028137
coco,W/SG12/top50/SG15-A075,W/SG12/top50,bottle,0.45,0.47857602965728485,0.005573046100615153
coco,W/SG12/top50/SG15-A075,W/SG12/top50,bus,0.45,0.907652277450871,-0.010205936519820824
coco,W/SG12/top50/SG15-A075,W/SG12/top50,car,0.45,0.5639556320182333,0.0010499390084456328
coco,W/SG12/top50/SG15-A075,W/SG12/top50,cat,0.45,0.8018940109427475,-0.03682350652374777
coco,W/SG12/top50/SG15-A075,W/SG12/top50,chair,0.45,0.42957595029335194,0.0021239172746491675
coco,W/SG12/top50/SG15-A075,W/SG12/top50,cow,0.45,0.78183466021982,-0.03407883042589832
coco,W/SG12/top50/SG15-A075,W/SG12/top50,dining table,0.45,0.31306798753582804,-0.06767641576168104
coco,W/SG12/top50/SG15-A075,W/SG12/top50,dog,0.45,0.7150793326970928,-0.031019416070110495
coco,W/SG12/top50/SG15-A075,W/SG12/top50,horse,0.45,0.6532155198882311,-0.0007979944854993315
coco,W/SG12/top50/SG15-A075,W/SG12/top50,motorbike,0.45,0.6357783426484329,0.008246528678233722
coco,W/SG12/top50/SG15-A075,W/SG12/top50,person,0.45,0.22063975326824625,-0.017102980317054428
coco,W/SG12/top50/SG15-A075,W/SG12/top50,potted plant,0.45,0.6454174840521121,-0.015130198975440878
coco,W/SG12/top50/SG15-A075,W/SG12/top50,sheep,0.45,0.805850728553556,-0.061854529899358135
coco,W/SG12/top50/SG15-A075,W/SG12/top50,sofa,0.45,0.6234926886293144,0.02502085929750608
coco,W/SG12/top50/SG15-A075,W/SG12/top50,train,0.45,0.6473306018421326,0.029212039654554434
coco,W/SG12/top50/SG15-A075,W/SG12/top50,tv,0.45,0.6990790942789513,-0.001127179768613873
voc,W/SG12/top50/SG15-B,W/SG12/top50,aeroplane,0.45,0.8483110795744809,-0.006872087751193301
voc,W/SG12/top50/SG15-B,W/SG12/top50,bicycle,0.45,0.7439777492944761,-0.001312343663332105
voc,W/SG12/top50/SG15-B,W/SG12/top50,bird,0.45,0.8548620433484954,-0.0016253430555567272
voc,W/SG12/top50/SG15-B,W/SG12/top50,boat,0.45,0.8368410033178376,0.001932818797918845
voc,W/SG12/top50/SG15-B,W/SG12/top50,bottle,0.45,0.8570978157027992,-0.007976484722359012
voc,W/SG12/top50/SG15-B,W/SG12/top50,bus,0.45,0.9112682948248179,-0.0036470234100904886
voc,W/SG12/top50/SG15-B,W/SG12/top50,car,0.45,0.8356283128900146,0.0024646984081868606
voc,W/SG12/top50/SG15-B,W/SG12/top50,cat,0.45,0.8069326444299125,-0.001950995618995921
voc,W/SG12/top50/SG15-B,W/SG12/top50,chair,0.45,0.6815942519090025,0.004131224021051816
voc,W/SG12/top50/SG15-B,W/SG12/top50,cow,0.45,0.8388224654286764,-0.00679870527121218
voc,W/SG12/top50/SG15-B,W/SG12/top50,dining-table,0.45,0.4599403213223076,-0.001598281605916796
voc,W/SG12/top50/SG15-B,W/SG12/top50,dog,0.45,0.8988856722587799,-0.003225643832924008
voc,W/SG12/top50/SG15-B,W/SG12/top50,horse,0.45,0.8812853565546258,0.0037817027223875366
voc,W/SG12/top50/SG15-B,W/SG12/top50,motorbike,0.45,0.8515566829125321,0.0014928956158035689
voc,W/SG12/top50/SG15-B,W/SG12/top50,person,0.45,0.7230302725631708,0.00043991483037320034
voc,W/SG12/top50/SG15-B,W/SG12/top50,potted-plant,0.45,0.7336337407375862,-0.0003818729622174777
voc,W/SG12/top50/SG15-B,W/SG12/top50,sheep,0.45,0.784246401261106,-0.0002480340398067771
voc,W/SG12/top50/SG15-B,W/SG12/top50,sofa,0.45,0.9455490691005666,-0.002167360845241717
voc,W/SG12/top50/SG15-B,W/SG12/top50,train,0.45,0.6707148420004144,0.0013731292927714467
voc,W/SG12/top50/SG15-B,W/SG12/top50,tv,0.45,0.7780582552118317,-0.006744269627059651
coco,W/SG12/top50/SG15-B,W/SG12/top50,aeroplane,0.45,0.5898878759893712,-0.00013927934274315934
coco,W/SG12/top50/SG15-B,W/SG12/top50,bicycle,0.45,0.5843075746441887,0.003983832316104996
coco,W/SG12/top50/SG15-B,W/SG12/top50,bird,0.45,0.710821352349147,-0.005173868214047195
coco,W/SG12/top50/SG15-B,W/SG12/top50,boat,0.45,0.5305897247743199,0.0004963951519059151
coco,W/SG12/top50/SG15-B,W/SG12/top50,bottle,0.45,0.4733209669487548,0.0003179833920851083
coco,W/SG12/top50/SG15-B,W/SG12/top50,bus,0.45,0.9144299408102402,-0.003428273160451578
coco,W/SG12/top50/SG15-B,W/SG12/top50,car,0.45,0.5612392460833691,-0.0016664469264185966
coco,W/SG12/top50/SG15-B,W/SG12/top50,cat,0.45,0.8351515715781628,-0.003565945888332478
coco,W/SG12/top50/SG15-B,W/SG12/top50,chair,0.45,0.42935451876390324,0.0019024857452004662
coco,W/SG12/top50/SG15-B,W/SG12/top50,cow,0.45,0.8119742329058596,-0.003939257739858704
coco,W/SG12/top50/SG15-B,W/SG12/top50,dining table,0.45,0.3763957277070762,-0.004348675590432893
coco,W/SG12/top50/SG15-B,W/SG12/top50,dog,0.45,0.7425505845162544,-0.0035481642509488376
coco,W/SG12/top50/SG15-B,W/SG12/top50,horse,0.45,0.6528693097861472,-0.0011442045875832418
coco,W/SG12/top50/SG15-B,W/SG12/top50,motorbike,0.45,0.6256156817807373,-0.00191613218946185
coco,W/SG12/top50/SG15-B,W/SG12/top50,person,0.45,0.23719543104009397,-0.0005473025452067126
coco,W/SG12/top50/SG15-B,W/SG12/top50,potted plant,0.45,0.6582430482624522,-0.002304634765100788
coco,W/SG12/top50/SG15-B,W/SG12/top50,sheep,0.45,0.8608628439781775,-0.006842414474736658
coco,W/SG12/top50/SG15-B,W/SG12/top50,sofa,0.45,0.601660183320042,0.003188353988233694
coco,W/SG12/top50/SG15-B,W/SG12/top50,train,0.45,0.6229434020239972,0.004824839836419015
coco,W/SG12/top50/SG15-B,W/SG12/top50,tv,0.45,0.7003117528281642,0.00010547878059896654
